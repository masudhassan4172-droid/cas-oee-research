# Data dictionary

Every stage directory contains `timeseries.csv`, `events.csv`, `run_summary.csv`, and `manifest.json`. CSV rows are raw simulation records; summaries and plots in `analysis/` are derived.

## `timeseries.csv`

- `run_id`, `seed`, `stage`, `environment`, `network`, `representation`, `selection`: condition and replicate identifiers.
- `generation`: census index; each trajectory has `T+1` rows, from 0 through `T`.
- `environment_period`: generations between deterministic target complementation; 0 means static.
- `environment_code`: packed target vector recorded each generation.
- `population`, `mutation_rate_per_bit`: model settings.
- `unique_genotypes`, `new_genotypes`: census count and first-seen genotype count; generation 0 is baseline.
- `genotype_state_sha256`: order-invariant checksum of the genotype census, used by the neutral control.
- `unique_phenotypes`, `new_phenotypes`, `cumulative_phenotypes_seen`, `phenotype_space_size`: descriptor counts and finite-state coverage.
- `genotype_novelty_fraction`: new genotypes divided by census size.
- `shannon_phenotype_entropy_nats`: Shannon entropy of census phenotype frequencies, in nats.
- `reappearing_phenotypes`: previously observed phenotypes present now after at least one census of absence.
- `exact_phenotype_state_recurrence`: 1 if this phenotype-abundance census state appeared earlier in that run.
- `mean_environment_match`: population mean of the defined bounded match score.
- `mean_contest_success`: mean edge-contest success, expected to equal 0.5 for a complete graph census of pairwise contests.
- `mutation_bits_previous_transition`, `phenotype_changes_previous_transition`, `reappearing_phenotypes_previous_transition`: realized counts for the transition that produced the current census; empty in generation 0.

## `events.csv`

One row per first-seen phenotype event. `phenotype_code` is the integer encoding under that run's representation. `origin_generation` is its first census. `followup_steps` is the number of observed post-origin censuses (maximum 40); `present_steps` counts censuses in which a tagged descendant still expressed the phenotype. `persistent` is 1/0 for complete events and blank for censored events. `right_censored=1` marks incomplete follow-up.

## `run_summary.csv`

One row per independent simulation run. Contains settings and graph diagnostics, total first-seen genotype and phenotype events, eligible/censored persistence-event counts, the version 0.2 as-frozen rate per 1,000 total births, final phenotype coverage, and late-window descriptive outcomes. The post-run eligible-exposure correction is in derived analysis tables and is documented in `ANALYSIS_AMENDMENT.md`. The simulation run/seed is the replicate unit.

## `manifest.json`

Records exact per-run settings and seeds, Python version, RNG description, model and runner source hashes, and hashes of the raw CSV files. Never edit a manifest to retrofit a different simulation configuration.
