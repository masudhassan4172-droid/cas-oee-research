# Post-run analysis amendment: persistence censoring

**Date:** 2026-09-28  
**Status:** Post-run correction; all affected estimates remain exploratory.

## Issue found

The frozen version 0.2 endpoint divided persistent phenotype events by all \(N\times T\) births. However, an event needs 40 subsequent censuses before it can be classified. Events first observed during the final 40 generations are right-censored, while early events have complete follow-up. The original rate therefore included birth opportunities that could not produce an observed mature event. This is particularly consequential when treatment conditions change the timing or number of late discoveries.

## Reanalysis

The corrected exposure-normalized rate counts qualifying events that originate no later than generation \(T-40\), and divides by \(N(T-40)\), the births in generations 1 through \(T-40\). A qualifying event must have all 40 follow-up censuses and meet the frozen threshold of presence in at least 32 of those censuses. The `run_summary.csv` fields and first analysis using the original \(NT\) denominator are retained unchanged. The corrected estimate and the as-frozen estimate are both reported in derived tables.

This is an analysis correction made after inspecting the first outcome summaries and censor counts. It is **not** a confirmatory preregistered estimand. The corrected analysis cannot be presented as if specified before data collection. No simulation, seed, fitness rule, mutation parameter, treatment, event threshold, or model code was changed. The reanalysis reads the preserved raw event logs.

## Consequences for interpretation

The corrected eligible-exposure analysis is the more interpretable descriptive rate for comparing conditions, but it remains exploratory with 12 seed blocks per primary cell. Both sets of estimates should be shown, and conclusions should be limited to this finite computational model. The correction does not establish OEE or verify the research-gap claim.
