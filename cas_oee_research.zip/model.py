#!/usr/bin/env python3
"""Minimal finite-population evolutionary model for the CAS–OEE study."""
import hashlib
import json
import math
import random
import statistics
import sys
from collections import Counter, defaultdict

BITS = 32
PRIMARY_REPRESENTATION = "popcount9"
ALTERNATE_REPRESENTATION = "parity256"
PERSISTENCE_WINDOW = 40
PERSISTENCE_MIN_PRESENT = 32


def _popcount(value):
    return bin(value).count("1")


def derive_seed(seed, label):
    payload = (str(seed) + ":" + label).encode("utf-8")
    return int.from_bytes(hashlib.sha256(payload).digest()[:8], "big")


def decode(genome, representation=PRIMARY_REPRESENTATION):
    if representation == PRIMARY_REPRESENTATION:
        traits = tuple(_popcount((genome >> (8 * locus)) & 255) for locus in range(4))
        code = ((traits[0] * 9 + traits[1]) * 9 + traits[2]) * 9 + traits[3]
        return traits, code, 6561
    if representation == ALTERNATE_REPRESENTATION:
        traits = tuple(_popcount((genome >> (4 * locus)) & 15) & 1 for locus in range(8))
        code = sum(value << locus for locus, value in enumerate(traits))
        return traits, code, 256
    raise ValueError("Unknown representation: " + str(representation))


def mutate(genome, rate, rng):
    if rate <= 0:
        return genome, 0
    if rate >= 1:
        return genome ^ ((1 << BITS) - 1), BITS
    flipped = 0
    position = -1
    log_no_flip = math.log1p(-rate)
    while True:
        position += int(math.log1p(-rng.random()) / log_no_flip) + 1
        if position >= BITS:
            break
        flipped ^= 1 << position
    return genome ^ flipped, _popcount(flipped)


def _connected(adjacency):
    reached = {0}
    stack = [0]
    while stack:
        node = stack.pop()
        for neighbor in adjacency[node]:
            if neighbor not in reached:
                reached.add(neighbor)
                stack.append(neighbor)
    return len(reached) == len(adjacency)


def make_graph(population, kind, rng, degree=4, swaps_per_edge=20):
    if population <= degree or population % 2 or degree % 2:
        raise ValueError("Population and even degree are incompatible with this graph generator")
    if kind not in ("ring", "rewired_regular"):
        raise ValueError("Unknown graph type: " + str(kind))
    if kind == "ring":
        return [set(((node + offset) % population) for offset in (-2, -1, 1, 2)) for node in range(population)]
    adjacency = [set(((node + offset) % population) for offset in (-2, -1, 1, 2)) for node in range(population)]
    edges = {(min(node, neighbor), max(node, neighbor)) for node in range(population) for neighbor in adjacency[node] if node < neighbor}
    attempts = 0
    accepted = 0
    target = swaps_per_edge * len(edges)
    while accepted < target and attempts < target * 30:
        attempts += 1
        edge_one, edge_two = rng.sample(tuple(edges), 2)
        a, b = edge_one
        c, d = edge_two
        if len({a, b, c, d}) < 4:
            continue
        if rng.random() < 0.5:
            proposed = ((min(a, c), max(a, c)), (min(b, d), max(b, d)))
        else:
            proposed = ((min(a, d), max(a, d)), (min(b, c), max(b, c)))
        if proposed[0][0] == proposed[0][1] or proposed[1][0] == proposed[1][1]:
            continue
        if proposed[0] == proposed[1] or proposed[0] in edges or proposed[1] in edges:
            continue
        trial = [set(neighbors) for neighbors in adjacency]
        for left, right in (edge_one, edge_two):
            trial[left].remove(right)
            trial[right].remove(left)
        for left, right in proposed:
            trial[left].add(right)
            trial[right].add(left)
        if not _connected(trial):
            continue
        adjacency = trial
        edges.remove(edge_one)
        edges.remove(edge_two)
        edges.add(proposed[0])
        edges.add(proposed[1])
        accepted += 1
    if accepted < target:
        raise RuntimeError("Random regular graph rewiring did not reach its frozen swap count")
    return adjacency


def graph_summary(adjacency):
    population = len(adjacency)
    degrees = [len(neighbors) for neighbors in adjacency]
    triangles = 0
    triples = 0
    for node, neighbors in enumerate(adjacency):
        degree = len(neighbors)
        triples += degree * (degree - 1) / 2
        for left in neighbors:
            for right in neighbors:
                if left < right and right in adjacency[left]:
                    triangles += 1
    triangles //= 1
    transitivity = triangles / triples if triples else 0.0
    edges = sum(degrees) // 2
    return {"population": population, "degree_min": min(degrees), "degree_max": max(degrees), "edges": edges, "degree_sum": sum(degrees), "transitivity": transitivity, "connected": _connected(adjacency)}


def match_score(traits, target):
    if len(traits) != len(target):
        raise ValueError("Phenotype and environmental target dimensions differ")
    scale = 8.0 if len(traits) == 4 else 1.0
    return 1.0 - sum(abs(value - optimum) / scale for value, optimum in zip(traits, target)) / len(traits)


def persistence_decision(present_steps, observed_steps, window=PERSISTENCE_WINDOW, minimum=PERSISTENCE_MIN_PRESENT):
    if observed_steps < window:
        return None
    return present_steps >= minimum


def lineage_carries_phenotype(phenotypes, lineage_tags, phenotype_code, event_bit):
    return any(code == phenotype_code and tags & event_bit for code, tags in zip(phenotypes, lineage_tags))


def validate_measurement():
    checks = {}
    checks["persistent_positive"] = persistence_decision(40, 40) is True
    checks["persistent_threshold"] = persistence_decision(32, 40) is True
    checks["below_threshold"] = persistence_decision(31, 40) is False
    checks["transient_negative"] = persistence_decision(8, 40) is False
    checks["right_censored"] = persistence_decision(40, 39) is None
    event_bit = 1 << 17
    checks["descendant_same_phenotype_positive"] = lineage_carries_phenotype([17, 4], [event_bit, 0], 17, event_bit)
    checks["unrelated_recurrence_negative"] = not lineage_carries_phenotype([17], [0], 17, event_bit)
    checks["descendant_changed_phenotype_negative"] = not lineage_carries_phenotype([18], [event_bit], 17, event_bit)
    checks["initial_baseline_excluded"] = True
    checks["primary_space_size"] = decode(0)[2] == 6561
    checks["alternate_space_size"] = decode(0, ALTERNATE_REPRESENTATION)[2] == 256
    if not all(checks.values()):
        failed = [name for name, passed in checks.items() if not passed]
        raise AssertionError("Measurement validation failed: " + ", ".join(failed))
    return checks


def validate_implementation():
    measurement = validate_measurement()
    calibration_rate = 0.002
    bit_opportunities = 32 * 50000
    calibration_rng = random.Random(derive_seed(880001, "mutation-calibration"))
    total_flips = 0
    for _ in range(50000):
        _, flips = mutate(0, calibration_rate, calibration_rng)
        total_flips += flips
    observed_rate = total_flips / float(bit_opportunities)
    tolerance = 5.0 * math.sqrt(calibration_rate * (1.0 - calibration_rate) / bit_opportunities)
    mutation_calibration_pass = abs(observed_rate - calibration_rate) <= tolerance
    graph_checks = {}
    for population in (50, 100):
        for kind in ("ring", "rewired_regular"):
            graph = make_graph(population, kind, random.Random(derive_seed(population, kind)))
            stats = graph_summary(graph)
            graph_checks["{}_{}".format(population, kind)] = stats["connected"] and stats["degree_min"] == 4 and stats["degree_max"] == 4 and stats["edges"] * 2 == stats["degree_sum"]
    sample_config = {"seed": 880002, "population": 50, "generations": 60, "environment_period": 0, "network": "rewired_regular", "representation": PRIMARY_REPRESENTATION, "selection": "ecological", "mutation_rate": calibration_rate}
    first = run_replicate(sample_config)
    second = run_replicate(sample_config)
    reproducibility_pass = first["series"] == second["series"] and first["events"] == second["events"] and first["summary"] == second["summary"]
    baseline_exclusion_pass = first["series"][0]["new_phenotypes"] == 0 and first["series"][0]["new_genotypes"] == 0
    result = {
        "measurement_checks": measurement,
        "mutation_calibration": {"nominal_per_bit_rate": calibration_rate, "observed_per_bit_rate": observed_rate, "five_standard_error_tolerance": tolerance, "bit_opportunities": bit_opportunities, "passed": mutation_calibration_pass},
        "graph_checks": graph_checks,
        "reproducibility_same_seed": reproducibility_pass,
        "initial_census_is_baseline": baseline_exclusion_pass,
        "passed": all(measurement.values()) and mutation_calibration_pass and all(graph_checks.values()) and reproducibility_pass and baseline_exclusion_pass,
    }
    if not result["passed"]:
        raise AssertionError("Implementation validation failed")
    return result


def _phenotype_population(genomes, representation):
    decoded = [decode(genome, representation) for genome in genomes]
    traits = [value[0] for value in decoded]
    codes = [value[1] for value in decoded]
    return traits, codes


def _target_initial(seed, representation):
    rng = random.Random(derive_seed(seed, "environment-initial"))
    if representation == PRIMARY_REPRESENTATION:
        return tuple(rng.randrange(9) for _ in range(4))
    return tuple(rng.randrange(2) for _ in range(8))


def run_replicate(config):
    seed = int(config["seed"])
    population = int(config.get("population", 100))
    generations = int(config.get("generations", 1000))
    mutation_rate = float(config.get("mutation_rate", 0.002))
    period = int(config.get("environment_period", 0))
    network = config.get("network", "rewired_regular")
    representation = config.get("representation", PRIMARY_REPRESENTATION)
    selection = config.get("selection", "ecological")
    contest_weight = float(config.get("contest_weight", 0.5))
    degree = int(config.get("degree", 4))
    if selection not in ("ecological", "neutral"):
        raise ValueError("Selection must be ecological or neutral")
    if not 0 <= mutation_rate <= 1:
        raise ValueError("Mutation rate must be between 0 and 1")
    if generations < 1:
        raise ValueError("At least one generation is required")
    initial_rng = random.Random(derive_seed(seed, "initial-genomes"))
    genomes = [initial_rng.getrandbits(BITS) for _ in range(population)]
    tags = [0] * population
    graph_rng = random.Random(derive_seed(seed, "graph-" + network + "-" + str(population)))
    adjacency = make_graph(population, network, graph_rng, degree=degree)
    graph_stats = graph_summary(adjacency)
    if not graph_stats["connected"] or graph_stats["degree_min"] != degree or graph_stats["degree_max"] != degree:
        raise AssertionError("Graph opportunity matching failed")
    target = _target_initial(seed, representation)
    evolution_label = "neutral-shared" if selection == "neutral" else "evolution-" + json.dumps({key: config.get(key) for key in ("environment_period", "network", "mutation_rate", "population", "representation")}, sort_keys=True)
    evo_rng = random.Random(derive_seed(seed, evolution_label))
    ever_seen = set()
    baseline_phenotypes = set()
    ever_genotypes = set()
    last_seen = {}
    previous_states = set()
    active_events = {}
    event_rows = []
    series = []
    mutation_bits_from_previous = ""
    phenotype_changes_from_previous = ""
    recurrent_codes_from_previous = ""
    for generation in range(generations + 1):
        if generation > 0 and period > 0 and generation % period == 0:
            if representation == PRIMARY_REPRESENTATION:
                target = tuple(8 - value for value in target)
            else:
                target = tuple(1 - value for value in target)
        traits, codes = _phenotype_population(genomes, representation)
        counts = Counter(codes)
        present = set(counts)
        new_codes = present - ever_seen if generation > 0 else set()
        new_genotypes = set(genomes) - ever_genotypes if generation > 0 else set()
        reappearing = sum(1 for code in present if code in last_seen and last_seen[code] < generation - 1)
        for code in sorted(active_events):
            event = active_events[code]
            if event["complete"]:
                continue
            if generation > event["origin_generation"]:
                carriers = lineage_carries_phenotype(codes, tags, code, 1 << code)
                event["observed_steps"] += 1
                if carriers:
                    event["present_steps"] += 1
                if event["observed_steps"] == PERSISTENCE_WINDOW:
                    event["persistent"] = persistence_decision(event["present_steps"], event["observed_steps"])
                    event["complete"] = True
                    event_rows.append({"phenotype_code": code, "origin_generation": event["origin_generation"], "followup_steps": event["observed_steps"], "present_steps": event["present_steps"], "persistent": int(event["persistent"]), "right_censored": 0})
        for code in sorted(new_codes):
            bit = 1 << code
            for index, current in enumerate(codes):
                if current == code:
                    tags[index] |= bit
            active_events[code] = {"origin_generation": generation, "observed_steps": 0, "present_steps": 0, "persistent": None, "complete": False}
        for code in present:
            last_seen[code] = generation
        ever_seen.update(present)
        ever_genotypes.update(genomes)
        if generation == 0:
            baseline_phenotypes = set(present)
        state = tuple(sorted(counts.items()))
        genotype_hash = hashlib.sha256(",".join(str(value) for value in sorted(genomes)).encode("ascii")).hexdigest()
        state_recurrence = int(state in previous_states)
        previous_states.add(state)
        entropy = -sum((count / float(population)) * math.log(count / float(population)) for count in counts.values())
        matches = [match_score(vector, target) for vector in traits]
        edges = [(left, right) for left, neighbors in enumerate(adjacency) for right in neighbors if left < right]
        wins = [0.0] * population
        for left, right in edges:
            if matches[left] > matches[right]:
                wins[left] += 1.0
            elif matches[right] > matches[left]:
                wins[right] += 1.0
            else:
                wins[left] += 0.5
                wins[right] += 0.5
        contest_scores = [wins[index] / degree for index in range(population)]
        fitness = [0.25 + matches[index] + contest_weight * contest_scores[index] for index in range(population)]
        if selection == "neutral":
            fitness = [1.0] * population
        series.append({
            "generation": generation,
            "environment_period": period,
            "environment_code": sum(value << (4 * index) for index, value in enumerate(target)) if representation == PRIMARY_REPRESENTATION else sum(value << index for index, value in enumerate(target)),
            "network": network,
            "representation": representation,
            "selection": selection,
            "population": population,
            "mutation_rate_per_bit": mutation_rate,
            "unique_genotypes": len(set(genomes)),
            "new_genotypes": len(new_genotypes),
            "genotype_state_sha256": genotype_hash,
            "unique_phenotypes": len(present),
            "new_phenotypes": len(new_codes),
            "cumulative_phenotypes_seen": len(ever_seen),
            "phenotype_space_size": decode(genomes[0], representation)[2],
            "genotype_novelty_fraction": len(new_genotypes) / float(population),
            "shannon_phenotype_entropy_nats": entropy,
            "reappearing_phenotypes": reappearing,
            "exact_phenotype_state_recurrence": state_recurrence,
            "mean_environment_match": statistics.mean(matches),
            "mean_contest_success": statistics.mean(contest_scores),
            "mutation_bits_previous_transition": mutation_bits_from_previous,
            "phenotype_changes_previous_transition": phenotype_changes_from_previous,
            "reappearing_phenotypes_previous_transition": recurrent_codes_from_previous,
        })
        if generation == generations:
            break
        parent_indices = evo_rng.choices(range(population), weights=fitness, k=population)
        offspring = []
        offspring_tags = []
        total_mutation_bits = 0
        phenotype_changes = 0
        for parent_index in parent_indices:
            child, flips = mutate(genomes[parent_index], mutation_rate, evo_rng)
            total_mutation_bits += flips
            if decode(child, representation)[1] != codes[parent_index]:
                phenotype_changes += 1
            offspring.append(child)
            offspring_tags.append(tags[parent_index])
        future_codes = [decode(child, representation)[1] for child in offspring]
        future_seen = set(future_codes)
        recurrent_codes_from_previous = sum(1 for code in future_seen if code in ever_seen)
        mutation_bits_from_previous = total_mutation_bits
        phenotype_changes_from_previous = phenotype_changes
        genomes = offspring
        tags = offspring_tags
    for code, event in sorted(active_events.items()):
        if not event["complete"]:
            event_rows.append({"phenotype_code": code, "origin_generation": event["origin_generation"], "followup_steps": event["observed_steps"], "present_steps": event["present_steps"], "persistent": "", "right_censored": 1})
    complete_events = [row for row in event_rows if row["right_censored"] == 0]
    persistent_count = sum(int(row["persistent"]) for row in complete_events)
    unique_genotypes_final = len(set(genomes))
    summary = {
        "stage": config.get("stage", "unspecified"),
        "run_id": config.get("run_id", str(seed)),
        "seed": seed,
        "population": population,
        "generations": generations,
        "environment": config.get("environment", "unspecified"),
        "environment_period": period,
        "network": network,
        "representation": representation,
        "selection": selection,
        "mutation_rate_per_bit": mutation_rate,
        "degree": degree,
        "edges": graph_stats["edges"],
        "degree_sum": graph_stats["degree_sum"],
        "transitivity": graph_stats["transitivity"],
        "connected": int(graph_stats["connected"]),
        "first_seen_phenotypes": len(ever_seen - baseline_phenotypes),
        "observable_novelty_events": sum(int(row["new_phenotypes"]) for row in series),
        "observable_new_genotypes": sum(int(row["new_genotypes"]) for row in series),
        "eligible_persistence_events": len(complete_events),
        "persistent_innovations": persistent_count,
        "persistent_innovations_per_1000_births": 1000.0 * persistent_count / float(population * generations),
        "censored_persistence_events": sum(int(row["right_censored"]) for row in event_rows),
        "final_phenotype_coverage_fraction": series[-1]["cumulative_phenotypes_seen"] / float(series[-1]["phenotype_space_size"]),
        "final_unique_genotypes": unique_genotypes_final,
        "late_window_new_phenotypes_per_generation": statistics.mean([row["new_phenotypes"] for row in series[max(0, generations - min(100, generations)):generations]]) if generations else 0.0,
        "late_window_environment_match": statistics.mean([row["mean_environment_match"] for row in series[max(0, generations - min(100, generations)):generations]]) if generations else 0.0,
    }
    return {"summary": summary, "series": series, "events": event_rows, "graph": graph_stats}
