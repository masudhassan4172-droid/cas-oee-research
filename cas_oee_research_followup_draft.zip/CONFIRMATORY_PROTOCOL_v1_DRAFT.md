# Confirmatory follow-up protocol — v1.0 draft

**Status:** PROPOSED design draft. It has not been externally preregistered, independently reviewed, or run. Freeze the model and register this protocol before generating any follow-up outcomes. The existing 240 trajectories remain exploratory pilot data and must not be pooled with the confirmatory sample for the primary estimate.

## Evidence labels

- **OBSERVED:** The pilot included 12 seed blocks per primary factorial cell. Its fast-versus-static interaction estimate was −0.0078125 persistent events per 1,000 eligible births, with seed-block SD 0.02848396 and percentile-bootstrap 95% interval [−0.0234375, 0.0078125].
- **PROPOSED:** The follow-up uses a preregistered fast-periodic-versus-static interaction as its single primary contrast. The number of seed blocks remains undecided pending a justified effect or precision target.
- **INTERPRETED:** The current interval spans zero; the pilot does not resolve a network interaction. It is not evidence that the interaction is exactly zero.
- **HYPOTHESIZED:** Switching regime may modify the difference between the two graph structures. No sign or optimal switching period is predicted.
- **NOT SUPPORTED:** These finite-state runs cannot establish open-ended evolution, unbounded novelty, a universal network effect, or a timescale mechanism.

## Question and estimand

Does period-10 environmental switching, relative to a static environment, change the rate of persistent first-seen phenotype discoveries differently in a degree-four ring and a degree-preserving rewired graph, in this specific finite model?

For seed block (b), let (Y_{e,g,b}) be the number of qualifying discoveries per 1,000 eligible births for environment (e) and graph (g). The sole primary contrast is

\[
D_b=(Y_{fast,ring,b}-Y_{static,ring,b})-(Y_{fast,rewired,b}-Y_{static,rewired,b}).
\]

The primary estimand is the mean of (D_b) across independent seed blocks. Positive and negative values are both scientifically interpretable; use a two-sided 95% interval.

## Endpoint and exposure

Use the existing 32-bit genome and the primary four-locus popcount map (6,561 possible phenotypes). A phenotype discovery is registered once, at its first appearance after the initial census. The origin cohort is tagged; unrelated recurrence does not establish persistence. An event qualifies when a tagged descendant expresses that phenotype in at least 32 of the 40 subsequent censuses. Only origins at or before (T-40) enter the numerator. The run-level outcome is qualifying events divided by (N(T-40)), multiplied by 1,000. Record censored late discoveries separately. Do not substitute the earlier all-birth denominator.

## Frozen model and treatment matrix

After independent implementation review and gate tests, freeze the exact source hash, Python version, deterministic RNG derivation, graph generator, initialization procedure, and seed ledger. Keep population (N=100), per-bit mutation probability 0.002, horizon (T=1{,}000), ecological fitness, and the existing primary genotype-to-phenotype map fixed across primary arms. Novelty receives no fitness reward.

Each independent seed block contains these eight scheduled-environment × graph cells: static, period 200, period 50, and period 10, each crossed with ring and `rewired_regular`. Period-10 versus static is the sole primary contrast; period-200 and period-50 comparisons are secondary and exploratory. In each block, matched treatments use the same initialized founder population and starting environment, with separate deterministic evolution streams as defined in the frozen implementation. The number of seed blocks is not yet fixed. If the 0.02 planning benchmark below is justified and adopted, the illustrative allocation is 50 blocks (400 periodic factorial trajectories).

Add one secondary aperiodic-fast schedule in both graph arms for each seed block. Before the study, freeze a schedule generator that matches the periodic-fast arm's switch count and target occupancy over 1,000 generations while varying dwell times; save every generated schedule and checksum. Do not design schedules after looking at outcomes. The aperiodic comparison is a recurrence/periodicity diagnostic, not a second powered primary claim. Under the illustrative 50-block allocation it adds 100 trajectories, for 500 total.

Use the current ring and `rewired_regular` graph definitions only: both are connected, undirected, simple, degree four, and matched in population, edge count, and encounter count. The rewired graph is made by accepted degree-preserving connected edge swaps from a ring seed graph; do not call it a uniformly sampled random regular graph. Main follow-up total: 500 planned trajectories.

## Sample-size basis

The pilot's primary seed-block SD is based on only 12 blocks. For planning, its approximate one-sided 95% upper SD bound is 0.04421, using a chi-square variance bound with a Wilson–Hilferty quantile approximation. Under an independent, approximately normal seed-block contrast, a two-sided α=0.05 normal approximation gives 39 blocks for 80% power at an absolute interaction of 0.02 per 1,000 eligible births; a 25% margin gives 49. At 50 blocks the estimated normal-approximation power for 0.02 is 0.89.

The pilot's observed absolute estimate is 0.0078125. Powering to that value under the same approximation requires 252 blocks before margin and 315 after the 25% margin (rounding operationally to 320); this would imply 3,200 trajectories for the full eight periodic plus two aperiodic arms. These are planning calculations, not a claim that the pilot effect is real or important.

The 0.02 value is a **PROPOSED illustrative benchmark only**, not an empirically established minimum important effect or a claim of practical importance. The sensitivity table reports both this benchmark and the pilot estimate. No final sample size is selected. Before external registration, justify a scientific minimum effect or precision target independently of significance, then freeze and recompute the allocation. The normal approximation and small pilot do not guarantee realized power.

## Gates before the main factorial

1. An independently derived reference implementation, written without copying transition code, agrees on hand-checkable genome, mutation, graph, selection, and event-lineage cases. A second person reviews discrepancies; the current implementation does not count as independent validation of itself.
2. Synthetic tests cover first discovery, tagged persistence, unrelated reappearance, threshold boundaries, baseline exclusion, and the 40-generation right-censor boundary.
3. Mutation calibration is within a preregistered binomial tolerance over at least one million bit opportunities; graph checks establish connectedness, degree four, and equal edges; same-version seed replay is exact.
4. No-mutation controls produce zero post-baseline genotype and phenotype discoveries. Neutral-selection controls produce identical matched genotype histories across treatment labels. Use at least eight seed blocks per 2 × 2 treatment set for each control.
5. Aperiodic schedules pass checks for their frozen switch count, target occupancy, dwell-time variation, checksum, and exact reuse across the two graph arms of each seed block.
6. The blinded dry run exports complete generations, event logs, seeds, source hashes, and raw-file checksums; analysis reads only the frozen event-level endpoint.

Any gate failure stops confirmatory generation. Code or protocol changes get a new version, repeat relevant gates, and occur before treatment labels/outcomes are inspected.

## Analysis and reporting

- Independent seed blocks—not organisms, generations, events, or treatment rows—are inferential units.
- Report the primary mean (D_b), its 95% seed-block bootstrap interval (100,000 resamples; fixed analysis seed), the seed-block SD, and all block contrasts. Include the unadjusted paired-t interval as a prespecified sensitivity analysis.
- Report per-cell event counts, eligible births, rates, mutation opportunities, censored-event counts, environment-match summaries, and graph diagnostics. Keep the previously frozen and corrected pilot summaries separate from confirmatory output.
- Report period-200, period-50, aperiodic, mutation-rate, demographic, and representation analyses as secondary. They cannot replace the primary contrast. If formal secondary tests are added before registration, specify the family and multiplicity adjustment in that registration.
- Predefine failures as incomplete/crashed trajectories or failed integrity checks. Rerun only the identical configuration and seed after a documented technical failure; retain the failed artifacts. Never exclude a run because its outcome is unusual.
- Do not tune thresholds, conditions, seeds, transformations, or sample size after opening confirmatory outcomes. Report null, adverse, and mixed results.

## Scope and remaining prerequisites

The prior mutation and demographic sweeps are useful pilot controls, not proof that all opportunity effects have been removed. The follow-up holds census size, mutation probability, and duration fixed across primary arms and reports realized mutation counts. Keep mutation- and population-size sweeps secondary.

The prior alternate representation changes both phenotype decoding and fitness dimensionality; it is not a pure measurement robustness test. If representation robustness is required, implement parallel descriptor logging that cannot affect selection, add synthetic equivalence tests, and freeze it before the confirmatory run. Calibrate adaptive recovery time independently before considering any τ ratio. Neither extension is allowed to redefine the primary contrast.

**No confirmatory simulation should begin until** the source revision and seeds are frozen, the meaningful-effect or precision benchmark is justified, the independent implementation review is complete, and the dated protocol is registered in an appropriate repository. Until then, this file and its power table remain PROPOSED planning artifacts.
