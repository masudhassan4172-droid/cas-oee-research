#!/usr/bin/env python3
"""Run staged controls, the primary factorial, and robustness simulations."""
import argparse
import csv
import hashlib
import json
import platform
import sys
from pathlib import Path

from model import ALTERNATE_REPRESENTATION, PRIMARY_REPRESENTATION, run_replicate, validate_implementation

ENVIRONMENTS = {"static": 0, "slow": 200, "medium": 50, "fast": 10}
NETWORKS = ("rewired_regular", "ring")


def make_config(stage, run_id, seed, environment, network, generations, population=100, mutation_rate=0.002, representation=PRIMARY_REPRESENTATION, selection="ecological"):
    return {
        "stage": stage,
        "run_id": run_id,
        "seed": seed,
        "environment": environment,
        "environment_period": ENVIRONMENTS[environment],
        "network": network,
        "generations": generations,
        "population": population,
        "mutation_rate": mutation_rate,
        "representation": representation,
        "selection": selection,
        "degree": 4,
        "contest_weight": 0.5,
    }


def control_configs():
    configs = []
    for seed in range(1001, 1005):
        for environment in ("static", "fast"):
            for network in NETWORKS:
                configs.append(make_config("artifact_controls", "no_mutation_{}_{}_s{}".format(environment, network, seed), seed, environment, network, 300, population=60, mutation_rate=0.0))
    for seed in range(2001, 2005):
        for environment in ("static", "fast"):
            for network in NETWORKS:
                configs.append(make_config("artifact_controls", "neutral_{}_{}_s{}".format(environment, network, seed), seed, environment, network, 300, population=60, selection="neutral"))
    return configs


def opportunity_configs():
    configs = []
    for seed in range(3001, 3007):
        for environment in ("static", "fast"):
            for mutation_rate in (0.001, 0.002, 0.01):
                configs.append(make_config("mutation_opportunity", "mu{}_{}_s{}".format(mutation_rate, environment, seed), seed, environment, "rewired_regular", 500, mutation_rate=mutation_rate))
    for seed in range(4001, 4007):
        for environment in ("static", "fast"):
            for population in (50, 100, 200):
                configs.append(make_config("demographic_opportunity", "n{}_{}_s{}".format(population, environment, seed), seed, environment, "rewired_regular", 500, population=population))
    return configs


def main_configs():
    configs = []
    for seed in range(5001, 5013):
        for environment in ENVIRONMENTS:
            for network in NETWORKS:
                configs.append(make_config("primary_factorial", "{}_{}_s{}".format(environment, network, seed), seed, environment, network, 1000))
    return configs


def representation_configs():
    configs = []
    for seed in range(6001, 6005):
        for environment in ("static", "fast"):
            for network in NETWORKS:
                configs.append(make_config("representation_robustness", "{}_{}_s{}".format(environment, network, seed), seed, environment, network, 2000, representation=ALTERNATE_REPRESENTATION))
    return configs


def long_horizon_configs():
    configs = []
    for seed in range(7001, 7007):
        for environment in ("static", "fast"):
            for network in NETWORKS:
                configs.append(make_config("long_horizon", "{}_{}_s{}".format(environment, network, seed), seed, environment, network, 5000))
    return configs


def sha256_file(path):
    digest = hashlib.sha256()
    with open(path, "rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def write_stage(stage_name, configs, base_dir):
    stage_dir = Path(base_dir) / stage_name
    if stage_dir.exists() and any(stage_dir.iterdir()):
        raise FileExistsError("Refusing to overwrite raw output: {}".format(stage_dir))
    stage_dir.mkdir(parents=True, exist_ok=True)
    summaries = []
    series_path = stage_dir / "timeseries.csv"
    event_path = stage_dir / "events.csv"
    summary_path = stage_dir / "run_summary.csv"
    series_fields = None
    event_fields = ("run_id", "seed", "phenotype_code", "origin_generation", "followup_steps", "present_steps", "persistent", "right_censored")
    summary_fields = None
    with open(series_path, "w", newline="") as series_file, open(event_path, "w", newline="") as event_file, open(summary_path, "w", newline="") as summary_file:
        series_writer = None
        event_writer = csv.DictWriter(event_file, fieldnames=event_fields)
        event_writer.writeheader()
        summary_writer = None
        for index, config in enumerate(configs, 1):
            result = run_replicate(config)
            if series_writer is None:
                series_fields = tuple(result["series"][0].keys()) + ("run_id", "seed", "stage", "environment")
                series_writer = csv.DictWriter(series_file, fieldnames=series_fields)
                series_writer.writeheader()
            for row in result["series"]:
                series_writer.writerow(dict(row, run_id=config["run_id"], seed=config["seed"], stage=config["stage"], environment=config["environment"]))
            for row in result["events"]:
                event_writer.writerow(dict(row, run_id=config["run_id"], seed=config["seed"]))
            summary = result["summary"]
            summaries.append(summary)
            if summary_writer is None:
                summary_fields = tuple(summary.keys())
                summary_writer = csv.DictWriter(summary_file, fieldnames=summary_fields)
                summary_writer.writeheader()
            summary_writer.writerow(summary)
            if index == 1 or index % 10 == 0 or index == len(configs):
                print("{}: completed {}/{} runs".format(stage_name, index, len(configs)), flush=True)
    manifest = {
        "stage": stage_name,
        "status": "observed computational output; exploratory unless separately preregistered",
        "python_version": platform.python_version(),
        "rng": "Python random.Random; Mersenne Twister; streams derived with SHA-256",
        "seed_unit": "one independent simulation replicate; treatment arms share initial-genome and initial-environment streams when seed IDs match",
        "model_sha256": sha256_file(Path(__file__).with_name("model.py")),
        "runner_sha256": sha256_file(Path(__file__)),
        "planned_runs": configs,
        "raw_files": {
            "timeseries.csv": sha256_file(series_path),
            "events.csv": sha256_file(event_path),
            "run_summary.csv": sha256_file(summary_path),
        },
    }
    (stage_dir / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
    return summaries


def verify_artifact_controls(summaries, base_dir):
    no_mutation = [row for row in summaries if row["run_id"].startswith("no_mutation_")]
    neutral = [row for row in summaries if row["run_id"].startswith("neutral_")]
    controls_dir = Path(base_dir) / "artifact_controls"
    no_mutation_pass = len(no_mutation) == 16 and all(row["observable_novelty_events"] == 0 and row["observable_new_genotypes"] == 0 for row in no_mutation)
    state_hashes = {}
    with open(controls_dir / "timeseries.csv", newline="") as handle:
        for row in csv.DictReader(handle):
            if row["selection"] == "neutral":
                key = (row["seed"], row["run_id"])
                state_hashes.setdefault(key, []).append(row["genotype_state_sha256"])
    neutral_trajectories = {}
    for (seed, run_id), hashes in state_hashes.items():
        neutral_trajectories.setdefault(seed, []).append(tuple(hashes))
    neutral_pass = len(neutral) == 16 and all(len(set(neutral_trajectories.get(str(seed), []))) == 1 for seed in range(2001, 2005))
    graph_pass = all(row["degree"] == 4 and row["edges"] == 2 * row["population"] and row["degree_sum"] == 4 * row["population"] and row["connected"] == 1 for row in summaries)
    report = {
        "no_mutation_gate": {"passed": no_mutation_pass, "runs": len(no_mutation), "expected": "no novel genotype or phenotype after the initial census"},
        "neutral_selection_gate": {"passed": neutral_pass, "runs": len(neutral), "expected": "identical genotype histories across environment/network labels at a matched seed"},
        "degree_opportunity_gate": {"passed": graph_pass, "runs": len(summaries), "expected": "connected degree-4 graphs and exactly equal edge counts"},
        "main_factorial_authorized_by_gate": bool(no_mutation_pass and neutral_pass and graph_pass),
    }
    (controls_dir / "gate_report.json").write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    if not report["main_factorial_authorized_by_gate"]:
        raise RuntimeError("Artifact-control gate failed; primary factorial was not run")
    return report


def write_protocol_lock(base_dir, measurement_report):
    protocol = {
        "protocol_version": "0.2.0",
        "frozen_before_simulation": True,
        "primary_question": "Does environmental switching period interact with degree-matched interaction graph in predicting descendant-persistent first-seen phenotype discoveries in this finite model?",
        "primary_endpoint": "persistent phenotype discoveries per 1000 births; a new phenotype counts only if a descendant lineage retains that same phenotype in at least 32 of the 40 generations after first detection",
        "primary_contrast": "difference-in-differences: (fast ring - static ring) - (fast random-regular - static random-regular), calculated within independent seed blocks",
        "secondary_environment_levels": {key: value for key, value in ENVIRONMENTS.items()},
        "replication_unit": "independently seeded simulation run; seed block used for paired contrasts",
        "network_matching": "Both graph arms are connected, undirected, simple, degree 4; N and edge count are equal; rewired_regular is produced by 20 accepted degree-preserving connected edge swaps per edge from a degree-4 ring seed graph.",
        "representation": "32-bit genomes; primary genotype-to-phenotype map is four 8-bit loci decoded as four allele counts (0..8), giving 9^4 = 6561 possible phenotypes; parity256 is a predeclared alternative measurement/model representation.",
        "no_novelty_reward": True,
        "timescale_ratio": "Secondary and not analyzed in this run; tau_A requires independent calibration before any ratio is used.",
        "decision_labels": ["PROPOSED", "OBSERVED", "INTERPRETED", "HYPOTHESIZED", "NOT SUPPORTED"],
        "measurement_validation": measurement_report,
        "no_tuning_rule": "No parameter or endpoint changes after inspecting primary-factorial outcomes; changes require a new version and exploratory label.",
    }
    (Path(base_dir) / "protocol_lock.json").write_text(json.dumps(protocol, indent=2) + "\n", encoding="utf-8")


def run_all(base_dir):
    measurement = validate_implementation()
    (Path(base_dir) / "measurement_validation.json").write_text(json.dumps(measurement, indent=2) + "\n", encoding="utf-8")
    write_protocol_lock(base_dir, measurement)
    control_summary = write_stage("artifact_controls", control_configs(), base_dir)
    gate = verify_artifact_controls(control_summary, base_dir)
    print("Artifact-control gates passed; proceeding to opportunity controls.", flush=True)
    write_stage("mutation_opportunity", [row for row in opportunity_configs() if row["stage"] == "mutation_opportunity"], base_dir)
    write_stage("demographic_opportunity", [row for row in opportunity_configs() if row["stage"] == "demographic_opportunity"], base_dir)
    print("Opportunity controls complete; proceeding to the primary factorial.", flush=True)
    write_stage("primary_factorial", main_configs(), base_dir)
    write_stage("representation_robustness", representation_configs(), base_dir)
    write_stage("long_horizon", long_horizon_configs(), base_dir)
    summary = {"measurement_validation": measurement, "artifact_control_gates": gate, "stages_completed": ["artifact_controls", "mutation_opportunity", "demographic_opportunity", "primary_factorial", "representation_robustness", "long_horizon"]}
    (Path(base_dir) / "execution_summary.json").write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8")
    print("All frozen stages completed.", flush=True)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--out", default="data")
    parser.add_argument("--stage", choices=("all", "validate", "artifact_controls", "mutation_opportunity", "demographic_opportunity", "primary_factorial", "representation_robustness", "long_horizon"), default="all")
    args = parser.parse_args()
    base = Path(args.out)
    base.mkdir(parents=True, exist_ok=True)
    if args.stage == "all":
        run_all(base)
        return
    if args.stage == "validate":
        result = validate_implementation()
        (base / "measurement_validation.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
        print(json.dumps(result, indent=2))
        return
    if args.stage == "artifact_controls":
        summaries = write_stage("artifact_controls", control_configs(), base)
        print(json.dumps(verify_artifact_controls(summaries, base), indent=2))
        return
    config_map = {
        "mutation_opportunity": [row for row in opportunity_configs() if row["stage"] == "mutation_opportunity"],
        "demographic_opportunity": [row for row in opportunity_configs() if row["stage"] == "demographic_opportunity"],
        "primary_factorial": main_configs(),
        "representation_robustness": representation_configs(),
        "long_horizon": long_horizon_configs(),
    }
    write_stage(args.stage, config_map[args.stage], base)


if __name__ == "__main__":
    main()
