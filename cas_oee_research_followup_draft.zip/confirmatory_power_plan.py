#!/usr/bin/env python3
"""Create a prospective sample-size sensitivity table from pilot block variance."""
import argparse
import csv
import hashlib
import json
import math
import platform
from pathlib import Path
from statistics import NormalDist


DELTA_GRID = (0.0078125, 0.01, 0.015, 0.02, 0.025, 0.03, 0.04, 0.05)
ALPHA = 0.05
TARGET_POWER = 0.80
SAMPLE_SIZE_MARGIN = 1.25
ILLUSTRATIVE_BLOCKS = 50
ILLUSTRATIVE_BENCHMARK = 0.02


def chi_square_quantile_wilson_hilferty(probability, degrees_of_freedom):
    z_value = NormalDist().inv_cdf(probability)
    adjustment = 1.0 - 2.0 / (9.0 * degrees_of_freedom)
    spread = math.sqrt(2.0 / (9.0 * degrees_of_freedom))
    return degrees_of_freedom * (adjustment + z_value * spread) ** 3


def upper_sd_95_approx(sample_sd, sample_size):
    degrees_of_freedom = sample_size - 1
    lower_chi_square = chi_square_quantile_wilson_hilferty(0.05, degrees_of_freedom)
    return sample_sd * math.sqrt(degrees_of_freedom / lower_chi_square)


def normal_approximate_power(sample_size, effect, standard_deviation, alpha=ALPHA):
    distribution = NormalDist()
    critical_value = distribution.inv_cdf(1.0 - alpha / 2.0)
    noncentrality = abs(effect) * math.sqrt(sample_size) / standard_deviation
    return distribution.cdf(-critical_value - noncentrality) + 1.0 - distribution.cdf(critical_value - noncentrality)


def read_pilot_contrast(path):
    with path.open(newline="", encoding="utf-8") as handle:
        rows = list(csv.DictReader(handle))
    matches = [row for row in rows if row["contrast"] == "fast_vs_static_by_graph_interaction"]
    if len(matches) != 1:
        raise ValueError("Expected exactly one fast-vs-static seed-block contrast")
    row = matches[0]
    return int(row["n_seed_blocks"]), float(row["eligible_exposure_sd_across_seed_blocks"])


def write_plan(input_path, output_directory):
    sample_size, pilot_sd = read_pilot_contrast(input_path)
    conservative_sd = upper_sd_95_approx(pilot_sd, sample_size)
    z_sum = NormalDist().inv_cdf(1.0 - ALPHA / 2.0) + NormalDist().inv_cdf(TARGET_POWER)
    rows = []
    for effect in DELTA_GRID:
        normal_n = math.ceil((z_sum * conservative_sd / effect) ** 2)
        margin_n = math.ceil(SAMPLE_SIZE_MARGIN * normal_n)
        rows.append({
            "absolute_interaction_benchmark_per_1000_eligible_births": effect,
            "pilot_seed_blocks": sample_size,
            "pilot_seed_block_sd": pilot_sd,
            "approx_one_sided_95pct_upper_sd": conservative_sd,
            "two_sided_alpha": ALPHA,
            "target_power": TARGET_POWER,
            "normal_approx_blocks_for_target_power": normal_n,
            "blocks_with_25pct_margin": margin_n,
            "power_at_illustrative_50_blocks_normal_approx": normal_approximate_power(ILLUSTRATIVE_BLOCKS, effect, conservative_sd),
        })
    output_directory.mkdir(parents=True, exist_ok=True)
    table_path = output_directory / "confirmatory_sample_size_sensitivity.csv"
    with table_path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=tuple(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)
    digest = hashlib.sha256(input_path.read_bytes()).hexdigest()
    script_digest = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    protocol_path = Path(__file__).with_name("CONFIRMATORY_PROTOCOL_v1_DRAFT.md")
    protocol_digest = hashlib.sha256(protocol_path.read_bytes()).hexdigest()
    plan = {
        "status": "PROPOSED sensitivity calculation; no final sample size selected and not external preregistration",
        "pilot_input": str(input_path),
        "pilot_input_sha256": digest,
        "planning_script_sha256": script_digest,
        "protocol_sha256": protocol_digest,
        "pilot_primary_seed_blocks": sample_size,
        "pilot_primary_seed_block_sd": pilot_sd,
        "approx_one_sided_95pct_upper_sd": conservative_sd,
        "upper_sd_method": "chi-square variance upper bound with Wilson-Hilferty quantile approximation",
        "sample_size_method": "two-sided normal approximation; independent seed-block difference-in-differences",
        "alpha": ALPHA,
        "target_power": TARGET_POWER,
        "illustrative_benchmark": ILLUSTRATIVE_BENCHMARK,
        "pilot_observed_absolute_estimate": 0.0078125,
        "illustrative_seed_blocks": ILLUSTRATIVE_BLOCKS,
        "illustrative_primary_runs": ILLUSTRATIVE_BLOCKS * 4,
        "illustrative_full_4x2_factorial_runs": ILLUSTRATIVE_BLOCKS * 8,
        "approx_power_at_illustrative_blocks_for_0_02": normal_approximate_power(ILLUSTRATIVE_BLOCKS, ILLUSTRATIVE_BENCHMARK, conservative_sd),
        "interpretation": "No minimum important effect or final sample size is established. The 0.02 row is illustrative; the 0.0078125 row matches the absolute pilot point estimate. The normal approximation and small pilot make these sensitivity calculations, not definitive power guarantees.",
        "python_version": platform.python_version(),
        "table": table_path.name,
    }
    (output_directory / "confirmatory_planning.json").write_text(json.dumps(plan, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(plan, indent=2))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", default="analysis/seed_blocked_interaction_contrasts.csv")
    parser.add_argument("--out", default="analysis")
    args = parser.parse_args()
    write_plan(Path(args.input), Path(args.out))


if __name__ == "__main__":
    main()
