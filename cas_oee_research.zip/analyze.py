#!/usr/bin/env python3
"""Summarize independent simulation runs and export reproducible SVG figures."""
import argparse
import csv
import hashlib
import html
import json
import math
import platform
import random
import statistics
from collections import defaultdict
from pathlib import Path

BOOTSTRAP_DRAWS = 5000
ENV_ORDER = ("static", "slow", "medium", "fast")
NETWORK_ORDER = ("rewired_regular", "ring")
COLORS = {"rewired_regular": "#386CB0", "ring": "#F28E2B", "static": "#386CB0", "fast": "#F28E2B"}


def read_csv(path):
    with open(path, newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle))


def write_csv(path, rows, fields):
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def file_sha256(path):
    digest = hashlib.sha256()
    with open(path, "rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def event_rates_by_run(run_rows, event_rows, minimum_present=32, window=40):
    by_run = {}
    generations_by_run = {}
    for row in run_rows:
        eligible_generations = int(row["generations"]) - window
        if eligible_generations <= 0:
            raise ValueError("Run is too short for the frozen persistence horizon")
        generations_by_run[row["run_id"]] = int(row["generations"])
        by_run[row["run_id"]] = {"eligible_births": int(row["population"]) * eligible_generations, "events": 0}
    for event in event_rows:
        if event["right_censored"] != "0":
            continue
        run_id = event["run_id"]
        max_origin = generations_by_run[run_id] - window
        if int(event["origin_generation"]) <= max_origin and int(event["followup_steps"]) == window and int(event["present_steps"]) >= minimum_present:
            by_run[run_id]["events"] += 1
    return {run_id: 1000.0 * values["events"] / values["eligible_births"] for run_id, values in by_run.items()}


def bootstrap_interval(values, seed):
    values = [float(value) for value in values]
    if not values:
        return {"n": 0, "mean": 0.0, "sd": 0.0, "lower_95": 0.0, "upper_95": 0.0}
    mean_value = statistics.mean(values)
    standard_deviation = statistics.stdev(values) if len(values) > 1 else 0.0
    rng = random.Random(seed)
    means = []
    for _ in range(BOOTSTRAP_DRAWS):
        draw = [values[rng.randrange(len(values))] for _ in values]
        means.append(statistics.mean(draw))
    means.sort()
    lower = means[int(0.025 * (len(means) - 1))]
    upper = means[int(0.975 * (len(means) - 1))]
    return {"n": len(values), "mean": mean_value, "sd": standard_deviation, "lower_95": lower, "upper_95": upper}


def percentile(values, fraction):
    if not values:
        return 0.0
    position = fraction * (len(values) - 1)
    low = int(math.floor(position))
    high = int(math.ceil(position))
    if low == high:
        return values[low]
    return values[low] + (values[high] - values[low]) * (position - low)


def svg_text(x, y, value, size=13, anchor="middle", fill="#24343B", weight="normal", rotate=None):
    transform = " transform=\"rotate({} {} {})\"".format(rotate, x, y) if rotate is not None else ""
    return "<text x=\"{}\" y=\"{}\" text-anchor=\"{}\" font-family=\"Arial,sans-serif\" font-size=\"{}\" font-weight=\"{}\" fill=\"{}\"{}>{}</text>".format(x, y, anchor, size, weight, fill, transform, html.escape(str(value)))


def svg_header(width, height, title, subtitle):
    return ["<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"{}\" height=\"{}\" viewBox=\"0 0 {} {}\">".format(width, height, width, height), "<rect width=\"100%\" height=\"100%\" fill=\"white\"/>", svg_text(58, 36, title, 20, "start", "#172B35", "bold"), svg_text(58, 59, subtitle, 12, "start", "#596D75")]


def write_bar_figure(path, groups, title, subtitle, x_title, y_title, categories, series_names):
    width, height = 960, 540
    left, right, top, bottom = 92, 36, 95, 93
    plot_width = width - left - right
    plot_height = height - top - bottom
    high_value = max([group["upper_95"] for group in groups] + [group["mean"] for group in groups] + [0.0])
    y_max = high_value * 1.22 if high_value > 0 else 1.0
    pieces = svg_header(width, height, title, subtitle)
    for tick in range(6):
        value = y_max * tick / 5.0
        y = top + plot_height * (1.0 - value / y_max)
        pieces.append("<line x1=\"{}\" y1=\"{}\" x2=\"{}\" y2=\"{}\" stroke=\"#DDE4E8\" stroke-width=\"1\"/>".format(left, y, width - right, y))
        pieces.append(svg_text(left - 10, y + 4, "{:.3g}".format(value), 11, "end", "#596D75"))
    group_width = plot_width / max(1, len(categories))
    bar_width = min(42, group_width / (len(series_names) + 1))
    for category_index, category in enumerate(categories):
        center = left + group_width * (category_index + 0.5)
        pieces.append(svg_text(center, height - bottom + 27, category, 12, "middle", "#24343B"))
        for series_index, series_name in enumerate(series_names):
            record = next((item for item in groups if item["category"] == category and item["series"] == series_name), None)
            if record is None:
                continue
            x = center + (series_index - (len(series_names) - 1) / 2.0) * (bar_width + 9) - bar_width / 2.0
            y = top + plot_height * (1.0 - record["mean"] / y_max)
            bar_height = top + plot_height - y
            pieces.append("<rect x=\"{:.2f}\" y=\"{:.2f}\" width=\"{:.2f}\" height=\"{:.2f}\" fill=\"{}\" rx=\"2\"/>".format(x, y, bar_width, max(0.0, bar_height), COLORS.get(series_name, "#777777")))
            lower_y = top + plot_height * (1.0 - max(0.0, record["lower_95"]) / y_max)
            upper_y = top + plot_height * (1.0 - max(0.0, record["upper_95"]) / y_max)
            middle_x = x + bar_width / 2.0
            pieces.append("<line x1=\"{:.2f}\" y1=\"{:.2f}\" x2=\"{:.2f}\" y2=\"{:.2f}\" stroke=\"#172B35\" stroke-width=\"1.5\"/>".format(middle_x, lower_y, middle_x, upper_y))
            pieces.append("<line x1=\"{:.2f}\" y1=\"{:.2f}\" x2=\"{:.2f}\" y2=\"{:.2f}\" stroke=\"#172B35\" stroke-width=\"1.5\"/>".format(middle_x - 5, lower_y, middle_x + 5, lower_y))
            pieces.append("<line x1=\"{:.2f}\" y1=\"{:.2f}\" x2=\"{:.2f}\" y2=\"{:.2f}\" stroke=\"#172B35\" stroke-width=\"1.5\"/>".format(middle_x - 5, upper_y, middle_x + 5, upper_y))
    pieces.append("<line x1=\"{}\" y1=\"{}\" x2=\"{}\" y2=\"{}\" stroke=\"#24343B\"/>".format(left, top, left, top + plot_height))
    pieces.append("<line x1=\"{}\" y1=\"{}\" x2=\"{}\" y2=\"{}\" stroke=\"#24343B\"/>".format(left, top + plot_height, width - right, top + plot_height))
    pieces.append(svg_text(25, top + plot_height / 2, y_title, 13, "middle", "#24343B", rotate=-90))
    pieces.append(svg_text(left + plot_width / 2, height - 25, x_title, 12, "middle", "#24343B"))
    legend_y = top - 14
    legend_x = width - right - len(series_names) * 200
    for index, series_name in enumerate(series_names):
        x = legend_x + index * 200
        pieces.append("<rect x=\"{}\" y=\"{}\" width=\"13\" height=\"13\" fill=\"{}\"/>".format(x, legend_y - 10, COLORS.get(series_name, "#777777")))
        pieces.append(svg_text(x + 19, legend_y, series_name.replace("_", " "), 11, "start", "#24343B"))
    pieces.append("</svg>")
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("\n".join(pieces), encoding="utf-8")


def write_horizon_figure(path, grouped, sampled_generations):
    width, height = 960, 540
    left, right, top, bottom = 86, 34, 95, 90
    plot_width = width - left - right
    plot_height = height - top - bottom
    pieces = svg_header(width, height, "Phenotype-space coverage over the long horizon", "Mean fraction of the fixed 6,561-state space encountered; bands are not shown")
    for tick in range(6):
        value = tick / 5.0
        y = top + plot_height * (1.0 - value)
        pieces.append("<line x1=\"{}\" y1=\"{}\" x2=\"{}\" y2=\"{}\" stroke=\"#DDE4E8\"/>".format(left, y, width - right, y))
        pieces.append(svg_text(left - 10, y + 4, "{:.1f}".format(value), 11, "end", "#596D75"))
    for tick in range(6):
        value = tick * 1000
        x = left + plot_width * value / 5000.0
        pieces.append("<line x1=\"{}\" y1=\"{}\" x2=\"{}\" y2=\"{}\" stroke=\"#EEF1F3\"/>".format(x, top, x, top + plot_height))
        pieces.append(svg_text(x, top + plot_height + 23, value, 11, "middle", "#596D75"))
    line_styles = [("static", "rewired_regular", "#386CB0", ""), ("static", "ring", "#386CB0", "7 4"), ("fast", "rewired_regular", "#F28E2B", ""), ("fast", "ring", "#F28E2B", "7 4")]
    for environment, network, color, dash in line_styles:
        values = [grouped.get((environment, network, generation), 0.0) for generation in sampled_generations]
        points = []
        for generation, value in zip(sampled_generations, values):
            x = left + plot_width * generation / 5000.0
            y = top + plot_height * (1.0 - value)
            points.append("{:.2f},{:.2f}".format(x, y))
        dash_attr = " stroke-dasharray=\"{}\"".format(dash) if dash else ""
        pieces.append("<polyline fill=\"none\" stroke=\"{}\" stroke-width=\"2.5\"{} points=\"{}\"/>".format(color, dash_attr, " ".join(points)))
        for generation, value in zip(sampled_generations, values):
            x = left + plot_width * generation / 5000.0
            y = top + plot_height * (1.0 - value)
            pieces.append("<circle cx=\"{:.2f}\" cy=\"{:.2f}\" r=\"3\" fill=\"{}\"/>".format(x, y, color))
    pieces.append("<line x1=\"{}\" y1=\"{}\" x2=\"{}\" y2=\"{}\" stroke=\"#24343B\"/>".format(left, top, left, top + plot_height))
    pieces.append("<line x1=\"{}\" y1=\"{}\" x2=\"{}\" y2=\"{}\" stroke=\"#24343B\"/>".format(left, top + plot_height, width - right, top + plot_height))
    pieces.append(svg_text(24, top + plot_height / 2, "Phenotype-space coverage", 12, "middle", "#24343B", rotate=-90))
    pieces.append(svg_text(left + plot_width / 2, height - 25, "Generation", 12, "middle", "#24343B"))
    legend_items = [("static", "rewired regular", "#386CB0", ""), ("static", "ring", "#386CB0", "7 4"), ("fast", "rewired regular", "#F28E2B", ""), ("fast", "ring", "#F28E2B", "7 4")]
    for index, (environment, network, color, dash) in enumerate(legend_items):
        x = 475 + (index % 2) * 210
        y = 22 + (index // 2) * 18
        dash_attr = " stroke-dasharray=\"{}\"".format(dash) if dash else ""
        pieces.append("<line x1=\"{}\" y1=\"{}\" x2=\"{}\" y2=\"{}\" stroke=\"{}\" stroke-width=\"2.5\"{} />".format(x, y - 4, x + 28, y - 4, color, dash_attr))
        pieces.append(svg_text(x + 36, y, environment + " / " + network, 10, "start", "#24343B"))
    pieces.append("</svg>")
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("\n".join(pieces), encoding="utf-8")


def summarize(data_dir, output_dir):
    output_dir = Path(output_dir)
    data_dir = Path(data_dir)
    primary_rows = read_csv(data_dir / "primary_factorial" / "run_summary.csv")
    primary_events = read_csv(data_dir / "primary_factorial" / "events.csv")
    primary_eligible_rates = event_rates_by_run(primary_rows, primary_events)
    primary_by_condition = defaultdict(list)
    for row in primary_rows:
        primary_by_condition[(row["environment"], row["network"])].append(row)
    condition_summaries = []
    plot_groups = []
    for env_index, environment in enumerate(ENV_ORDER):
        for network_index, network in enumerate(NETWORK_ORDER):
            rows = primary_by_condition[(environment, network)]
            frozen_outcome = bootstrap_interval([row["persistent_innovations_per_1000_births"] for row in rows], 1100 + env_index * 17 + network_index)
            outcome = bootstrap_interval([primary_eligible_rates[row["run_id"]] for row in rows], 1200 + env_index * 17 + network_index)
            coverage = bootstrap_interval([row["final_phenotype_coverage_fraction"] for row in rows], 2200 + env_index * 17 + network_index)
            record = {"environment": environment, "network": network, "seed_blocks": outcome["n"], "eligible_exposure_rate_mean_per_1000_births": outcome["mean"], "eligible_exposure_rate_sd": outcome["sd"], "eligible_exposure_bootstrap_95_low": outcome["lower_95"], "eligible_exposure_bootstrap_95_high": outcome["upper_95"], "as_frozen_rate_mean_per_1000_total_births": frozen_outcome["mean"], "as_frozen_bootstrap_95_low": frozen_outcome["lower_95"], "as_frozen_bootstrap_95_high": frozen_outcome["upper_95"], "mean_eligible_events": statistics.mean([int(row["eligible_persistence_events"]) for row in rows]), "mean_persistent_events": statistics.mean([int(row["persistent_innovations"]) for row in rows]), "mean_censored_events": statistics.mean([int(row["censored_persistence_events"]) for row in rows]), "mean_coverage_fraction": coverage["mean"], "mean_late_discovery_rate": statistics.mean([float(row["late_window_new_phenotypes_per_generation"]) for row in rows]), "mean_environment_match": statistics.mean([float(row["late_window_environment_match"]) for row in rows])}
            condition_summaries.append(record)
            plot_groups.append({"category": environment, "series": network, "mean": outcome["mean"], "lower_95": outcome["lower_95"], "upper_95": outcome["upper_95"]})
    write_csv(output_dir / "primary_condition_summary.csv", condition_summaries, tuple(condition_summaries[0].keys()))
    seed_values = {(row["environment"], row["network"], row["seed"]): primary_eligible_rates[row["run_id"]] for row in primary_rows}
    frozen_seed_values = {(row["environment"], row["network"], row["seed"]): float(row["persistent_innovations_per_1000_births"]) for row in primary_rows}
    contrasts = []
    for env_index, environment in enumerate(("slow", "medium", "fast")):
        block_values = []
        frozen_block_values = []
        for seed in sorted({row["seed"] for row in primary_rows}):
            difference = (seed_values[(environment, "ring", seed)] - seed_values[("static", "ring", seed)]) - (seed_values[(environment, "rewired_regular", seed)] - seed_values[("static", "rewired_regular", seed)])
            block_values.append(difference)
            frozen_difference = (frozen_seed_values[(environment, "ring", seed)] - frozen_seed_values[("static", "ring", seed)]) - (frozen_seed_values[(environment, "rewired_regular", seed)] - frozen_seed_values[("static", "rewired_regular", seed)])
            frozen_block_values.append(frozen_difference)
        estimate = bootstrap_interval(block_values, 3200 + env_index)
        frozen_estimate = bootstrap_interval(frozen_block_values, 3300 + env_index)
        contrasts.append({"contrast": environment + "_vs_static_by_graph_interaction", "n_seed_blocks": estimate["n"], "eligible_exposure_mean_difference_in_differences": estimate["mean"], "eligible_exposure_sd_across_seed_blocks": estimate["sd"], "eligible_exposure_bootstrap_95_low": estimate["lower_95"], "eligible_exposure_bootstrap_95_high": estimate["upper_95"], "as_frozen_mean_difference_in_differences": frozen_estimate["mean"], "as_frozen_bootstrap_95_low": frozen_estimate["lower_95"], "as_frozen_bootstrap_95_high": frozen_estimate["upper_95"], "primary_contrast": int(environment == "fast")})
    write_csv(output_dir / "seed_blocked_interaction_contrasts.csv", contrasts, tuple(contrasts[0].keys()))
    mutation_rows = read_csv(data_dir / "mutation_opportunity" / "run_summary.csv")
    mutation_event_rows = read_csv(data_dir / "mutation_opportunity" / "events.csv")
    mutation_eligible_rates = event_rates_by_run(mutation_rows, mutation_event_rows)
    mutation_groups = defaultdict(list)
    for row in mutation_rows:
        mutation_groups[(row["environment"], float(row["mutation_rate_per_bit"]))].append(row)
    mutation_summaries = []
    mutation_plot = []
    mutation_rates = sorted({key[1] for key in mutation_groups})
    for env_index, environment in enumerate(("static", "fast")):
        for index, rate in enumerate(mutation_rates):
            rows = mutation_groups[(environment, rate)]
            frozen_outcome = bootstrap_interval([row["persistent_innovations_per_1000_births"] for row in rows], 4000 + env_index * 19 + index)
            outcome = bootstrap_interval([mutation_eligible_rates[row["run_id"]] for row in rows], 4100 + env_index * 19 + index)
            mutation_summaries.append({"environment": environment, "mutation_rate_per_bit": rate, "n_runs": outcome["n"], "mean_persistent_events_per_1000_eligible_births": outcome["mean"], "eligible_exposure_bootstrap_95_low": outcome["lower_95"], "eligible_exposure_bootstrap_95_high": outcome["upper_95"], "as_frozen_mean_per_1000_total_births": frozen_outcome["mean"], "as_frozen_bootstrap_95_low": frozen_outcome["lower_95"], "as_frozen_bootstrap_95_high": frozen_outcome["upper_95"], "mean_novelty_events": statistics.mean([int(row["observable_novelty_events"]) for row in rows])})
            mutation_plot.append({"category": "μ=" + str(rate), "series": environment, "mean": outcome["mean"], "lower_95": outcome["lower_95"], "upper_95": outcome["upper_95"]})
    write_csv(output_dir / "mutation_opportunity_summary.csv", mutation_summaries, tuple(mutation_summaries[0].keys()))
    demographic_rows = read_csv(data_dir / "demographic_opportunity" / "run_summary.csv")
    demographic_event_rows = read_csv(data_dir / "demographic_opportunity" / "events.csv")
    demographic_eligible_rates = event_rates_by_run(demographic_rows, demographic_event_rows)
    demographic_groups = defaultdict(list)
    for row in demographic_rows:
        demographic_groups[(row["environment"], int(row["population"]))].append(row)
    demographic_summaries = []
    population_plot = []
    for env_index, environment in enumerate(("static", "fast")):
        for index, population in enumerate((50, 100, 200)):
            rows = demographic_groups[(environment, population)]
            frozen_outcome = bootstrap_interval([row["persistent_innovations_per_1000_births"] for row in rows], 5000 + env_index * 19 + index)
            outcome = bootstrap_interval([demographic_eligible_rates[row["run_id"]] for row in rows], 5100 + env_index * 19 + index)
            demographic_summaries.append({"environment": environment, "population": population, "n_runs": outcome["n"], "mean_persistent_events_per_1000_eligible_births": outcome["mean"], "eligible_exposure_bootstrap_95_low": outcome["lower_95"], "eligible_exposure_bootstrap_95_high": outcome["upper_95"], "as_frozen_mean_per_1000_total_births": frozen_outcome["mean"], "as_frozen_bootstrap_95_low": frozen_outcome["lower_95"], "as_frozen_bootstrap_95_high": frozen_outcome["upper_95"], "mean_absolute_persistent_events": statistics.mean([int(row["persistent_innovations"]) for row in rows]), "mean_observable_novelty_events": statistics.mean([int(row["observable_novelty_events"]) for row in rows])})
            population_plot.append({"category": "N=" + str(population), "series": environment, "mean": outcome["mean"], "lower_95": outcome["lower_95"], "upper_95": outcome["upper_95"]})
    write_csv(output_dir / "demographic_opportunity_summary.csv", demographic_summaries, tuple(demographic_summaries[0].keys()))
    representation_rows = read_csv(data_dir / "representation_robustness" / "run_summary.csv")
    representation_event_rows = read_csv(data_dir / "representation_robustness" / "events.csv")
    representation_eligible_rates = event_rates_by_run(representation_rows, representation_event_rows)
    representation_summary = []
    for representation in sorted({row["representation"] for row in representation_rows}):
        for environment in ("static", "fast"):
            for network in NETWORK_ORDER:
                rows = [row for row in representation_rows if row["representation"] == representation and row["environment"] == environment and row["network"] == network]
                representation_summary.append({"representation": representation, "environment": environment, "network": network, "n_runs": len(rows), "mean_persistent_events_per_1000_eligible_births": statistics.mean([representation_eligible_rates[row["run_id"]] for row in rows]), "mean_as_frozen_rate_per_1000_total_births": statistics.mean([float(row["persistent_innovations_per_1000_births"]) for row in rows]), "mean_final_coverage_fraction": statistics.mean([float(row["final_phenotype_coverage_fraction"]) for row in rows]), "space_size": 256})
    write_csv(output_dir / "representation_summary.csv", representation_summary, tuple(representation_summary[0].keys()))
    threshold_rows = []
    for threshold in (20, 32, 40):
        threshold_rates = event_rates_by_run(primary_rows, primary_events, minimum_present=threshold)
        groups = defaultdict(list)
        for row in primary_rows:
            rate = threshold_rates[row["run_id"]]
            groups[(row["environment"], row["network"])].append(rate)
        for env_index, environment in enumerate(ENV_ORDER):
            for network_index, network in enumerate(NETWORK_ORDER):
                outcome = bootstrap_interval(groups[(environment, network)], 7100 + threshold * 31 + env_index * 7 + network_index)
                threshold_rows.append({"minimum_present_censuses_out_of_40": threshold, "environment": environment, "network": network, "n_seed_blocks": outcome["n"], "mean_persistent_events_per_1000_eligible_births": outcome["mean"], "bootstrap_95_low": outcome["lower_95"], "bootstrap_95_high": outcome["upper_95"]})
    write_csv(output_dir / "persistence_threshold_sensitivity.csv", threshold_rows, tuple(threshold_rows[0].keys()))
    horizon_rows = read_csv(Path(data_dir) / "long_horizon" / "timeseries.csv")
    horizon_points = list(range(0, 5001, 250))
    horizon_values = defaultdict(list)
    for row in horizon_rows:
        generation = int(row["generation"])
        if generation in horizon_points:
            key = (row["environment"], row["network"], generation)
            horizon_values[key].append(int(row["cumulative_phenotypes_seen"]) / float(row["phenotype_space_size"]))
    horizon_summary = []
    horizon_means = {}
    for environment in ("static", "fast"):
        for network in NETWORK_ORDER:
            for generation in horizon_points:
                values = horizon_values[(environment, network, generation)]
                estimate = bootstrap_interval(values, 6100 + generation // 250 + (0 if environment == "static" else 100) + (0 if network == "rewired_regular" else 20))
                horizon_means[(environment, network, generation)] = estimate["mean"]
                horizon_summary.append({"environment": environment, "network": network, "generation": generation, "n_runs": estimate["n"], "mean_coverage_fraction": estimate["mean"], "bootstrap_95_low": estimate["lower_95"], "bootstrap_95_high": estimate["upper_95"]})
    write_csv(output_dir / "long_horizon_coverage.csv", horizon_summary, tuple(horizon_summary[0].keys()))
    saturation = {}
    for environment in ("static", "fast"):
        for network in NETWORK_ORDER:
            rows = [row for row in read_csv(Path(data_dir) / "long_horizon" / "run_summary.csv") if row["environment"] == environment and row["network"] == network]
            saturation[environment + "/" + network] = {"n_runs": len(rows), "runs_at_or_above_95_percent_coverage": sum(float(row["final_phenotype_coverage_fraction"]) >= 0.95 for row in rows), "mean_final_coverage_fraction": statistics.mean([float(row["final_phenotype_coverage_fraction"]) for row in rows])}
    write_bar_figure(output_dir / "figure_primary_factorial.svg", plot_groups, "Descendant-persistent phenotype novelty", "Per 1,000 eligible births (generations 1 through T−40); whiskers are seed-block bootstrap 95% intervals", "Environmental switching condition", "Persistent discoveries / 1,000 eligible births", list(ENV_ORDER), list(NETWORK_ORDER))
    write_horizon_figure(output_dir / "figure_long_horizon.svg", horizon_means, horizon_points)
    write_bar_figure(output_dir / "figure_opportunity_controls.svg", mutation_plot, "Mutation opportunity control", "Persistent discoveries per 1,000 eligible births; static and fast conditions shown separately", "Per-bit mutation rate", "Persistent discoveries / 1,000 eligible births", ["μ=" + str(rate) for rate in mutation_rates], ["static", "fast"])
    write_bar_figure(output_dir / "figure_demographic_controls.svg", population_plot, "Population opportunity control", "Eligible-birth-normalized persistent discoveries; absolute counts are retained in the table", "Census size", "Persistent discoveries / 1,000 eligible births", ["N=50", "N=100", "N=200"], ["static", "fast"])
    observed_main = {
        "primary_run_count": len(primary_rows),
        "primary_replicates_per_cell": sorted(set(int(row["seed"]) for row in primary_rows)).__len__(),
        "endpoint_amendment": {"status": "POST-RUN analysis correction; exploratory", "reason": "The frozen v0.2 rate used all N*T births although phenotype events in the final 40 generations were right-censored for the persistence endpoint.", "corrected_exposure": "Persistent events divided by N*(T-40), using events originating no later than generation T-40.", "as_frozen_rate_and_contrasts_retained": True},
        "primary_contrasts": contrasts,
        "condition_means": condition_summaries,
        "long_horizon_coverage": saturation,
        "interpretation_status": "OBSERVED descriptive outputs; inference is exploratory and conditional on this finite model",
        "oee_claim": "NOT SUPPORTED by these finite-state simulations",
        "timescale_ratio": "NOT ANALYZED; tau_A was not independently calibrated",
    }
    (output_dir / "analysis_summary.json").write_text(json.dumps(observed_main, indent=2) + "\n", encoding="utf-8")
    analyzed_stages = ("artifact_controls", "primary_factorial", "mutation_opportunity", "demographic_opportunity", "representation_robustness", "long_horizon")
    input_hashes = {}
    for stage in analyzed_stages:
        for path in sorted((data_dir / stage).iterdir()):
            if path.is_file():
                input_hashes[str(path.relative_to(data_dir))] = file_sha256(path)
    for name in ("measurement_validation.json", "protocol_lock.json", "execution_summary.json"):
        path = data_dir / name
        if path.exists():
            input_hashes[name] = file_sha256(path)
    output_hashes = {path.name: file_sha256(path) for path in sorted(output_dir.iterdir()) if path.is_file() and path.name != "analysis_manifest.json"}
    analysis_manifest = {"analysis_version": "post-run-censoring-amendment-v0.2.1", "python_version": platform.python_version(), "analysis_script_sha256": file_sha256(Path(__file__)), "analysis_amendment_sha256": file_sha256(Path(__file__).with_name("ANALYSIS_AMENDMENT.md")), "bootstrap_draws": BOOTSTRAP_DRAWS, "bootstrap_seed_policy": "fixed seeds by table/condition; resampling over independent run or seed blocks", "input_hashes": input_hashes, "output_hashes": output_hashes, "amendment": observed_main["endpoint_amendment"]}
    (output_dir / "analysis_manifest.json").write_text(json.dumps(analysis_manifest, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(observed_main, indent=2))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--data", default="data")
    parser.add_argument("--out", default="analysis")
    args = parser.parse_args()
    summarize(args.data, args.out)


if __name__ == "__main__":
    main()
