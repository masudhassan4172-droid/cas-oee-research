# Ranked scientific risk register

This register distinguishes resolved implementation checks from limitations that still restrict the claims. **PROBLEM → WHY / THREAT → MINIMUM FIX → STRONGER FIX → TEST → DECISION RULE** is used for each item.

## Critical

### 1. OEE cannot be inferred from finite exploratory novelty

**Problem:** First-seen states are not OEE. **Why / threat:** the 32-bit genotype and fixed phenotype map have finite state spaces; a finite run cannot prove unbounded evolution or indefinitely ongoing innovation. **Minimum fix:** describe only the defined finite-horizon phenotype outcome. **Stronger fix:** use formal counterfactual and multi-hallmark OEE analyses in a model with suitable scaling properties. **Test:** compare the claim against the evidence hierarchy in `PROTOCOL.md`. **Decision:** do not claim OEE, unbounded evolution, or open-ended novelty from these simulations.

### 2. Primary descriptor space remains finite

**Problem:** the 6,561-state map can saturate. **Why / threat:** a low late discovery rate can reflect descriptor exhaustion; coverage is measurement-map dependent. **Minimum fix:** record coverage at every generation. **Stronger fix:** develop justified compositional or expanding representations and compare independent descriptor families. **Test:** 5,000-generation coverage trajectories plus the 256-state alternative. **Decision:** complete coverage blocks a sustained-discovery claim for that representation; incomplete coverage only supports a horizon-qualified statement.

### 3. Post-run censoring amendment

**Problem:** frozen v0.2 divided mature events by all \(NT\) births even though the last 40 generations could not complete the event horizon. **Why / threat:** differential late discovery can bias condition rates. **Minimum fix:** report both as-frozen and eligible-exposure estimates. **Stronger fix:** prospectively freeze a common event-origin window or survival analysis. **Test:** recompute from preserved event logs with origins at or before \(T-40\) and denominator \(N(T-40)\). **Decision:** call the corrected result exploratory; require a new prospectively specified run before confirmatory claims.

## Major

### 4. “Novelty” is a descriptor-level outcome

**Problem:** the phenotype vector is four allele-count traits, not behavior or functional innovation. **Why / threat:** a novel code may lack a meaningful ecological function. **Minimum fix:** call it first-seen phenotype discovery. **Stronger fix:** add predeclared behavioral and ecological-function descriptors. **Test:** demonstrate that a new descriptor changes an independently defined task or interaction. **Decision:** do not call the endpoint adaptive innovation or functional novelty without that evidence.

### 5. Many-to-one genotype–phenotype map

**Problem:** many genomes map to the same allele-count phenotype, and the alternate parity arm changes the environmental-match dimensionality as well as the descriptor. **Why / threat:** genotype change can occur without phenotype change; the alternate arm also changes the fitness landscape, so it is not a pure measurement robustness check. **Minimum fix:** report genotype and phenotype novelty separately and label the alternate arm as model-level sensitivity. **Stronger fix:** re-score identical genotype histories under several maps, then separately manipulate the evolutionary map/fitness relation. **Test:** compare the 6,561-state primary map to the 256-state parity model and track which parts of the result change. **Decision:** report reversals as representation/model dependence; do not select the map that produces the preferred pattern.

### 6. Persistence definition is operational, not uniquely privileged

**Problem:** the 32-of-40 rule allows up to eight absences and was chosen as a fixed working threshold. **Why / threat:** a different threshold changes event counts. **Minimum fix:** preserve the 32-of-40 rule and show threshold sensitivity. **Stronger fix:** calibrate the horizon from independent biological or dynamical criteria before a confirmatory run. **Test:** compare 20-, 32-, and 40-of-40 outcomes. **Decision:** if conclusions depend on threshold, report that dependence and do not elevate one threshold post hoc.

### 7. Mutation opportunity is a major alternative explanation

**Problem:** mutation supplies candidate variants. **Why / threat:** more mutation can raise raw discoveries without raising persistent events. **Minimum fix:** log realized mutation bits and use equal rates in the main factorial. **Stronger fix:** prospectively power a mutation × environment × graph design. **Test:** compare per-bit rates 0.001, 0.002, and 0.01 and report raw and eligible-birth-normalized outcomes. **Decision:** if effects track mutation supply or disappear after matching it, attribute them to the implemented mutation opportunity rather than environment or graph alone.

### 8. Population size changes opportunity

**Problem:** larger censuses create more births and mutation opportunities. **Why / threat:** absolute event counts can rise while per-birth rates fall. **Minimum fix:** retain absolute counts and per-eligible-birth rates. **Stronger fix:** cross population size with the primary factorial and use a precision-based design. **Test:** compare \(N=50,100,200\). **Decision:** distinguish total event production from rate per birth; do not call a raw-count increase an enhanced per-capita novelty process.

### 9. Network treatment is broader than a single structural property

**Problem:** ring and rewired graphs differ in clustering, path lengths, and partner arrangement even though degree matches. **Why / threat:** a contrast cannot identify which graph property caused it. **Minimum fix:** report exact graph generation and diagnostics. **Stronger fix:** manipulate clustering, path length, and spatial embedding independently. **Test:** preserve degree and connectedness, then conduct separate constrained rewiring contrasts. **Decision:** restrict any conclusion to these two graph constructions.

### 10. Network opportunity is matched only at degree and edge count

**Problem:** each agent has four contests, but neighbor phenotype similarity and local competition histories can differ. **Why / threat:** effective ecological exposure can differ even with equal encounter counts. **Minimum fix:** log contest success and graph metrics. **Stronger fix:** add controls matching or randomizing assortativity and local competition exposure. **Test:** compare per-generation contest distributions across graphs. **Decision:** if those distributions explain outcomes, interpret the contrast through local competition rather than abstract topology.

### 11. Environmental schedule combines rate and temporal regularity

**Problem:** environments are deterministic complements of all traits at once. **Why / threat:** switching interval, predictability, and synchronous target amplitude are bundled. **Minimum fix:** describe this as a periodic-complementation treatment. **Stronger fix:** add matched aperiodic schedules and partial-amplitude changes. **Test:** compare period-matched shuffled schedules under the same number and magnitude of target changes. **Decision:** do not generalize to stochastic or natural environmental variation without those tests.

### 12. The ecological model omits explicit resource stocks

**Problem:** “resource competition” is represented by pairwise contest scores, not resource acquisition, depletion, or replenishment. **Why / threat:** the model omits ecological feedbacks and population collapse. **Minimum fix:** describe the contest abstraction exactly. **Stronger fix:** add an explicit resource budget only if the minimal model warrants it. **Test:** compare resource-conserving allocation and variable-demography extensions. **Decision:** restrict conclusions to fixed-census local-competition dynamics.

### 13. No explicit spatial embedding

**Problem:** a ring graph is not a spatial simulation. **Why / threat:** network organization and geographic locality are not separated. **Minimum fix:** call it a ring-lattice interaction graph. **Stronger fix:** introduce coordinates and independently manipulate distance-constrained contacts. **Test:** match degree while varying embedding. **Decision:** do not infer a spatial effect from the ring-versus-rewired contrast.

### 14. Replicate count is exploratory

**Problem:** 12 seed blocks per primary cell, six for mutation/demography, and four for representation checks. **Why / threat:** uncertainty is large and estimates may be unstable; sample size was not power-calibrated for a smallest meaningful effect. **Minimum fix:** show all run-level outcomes and intervals. **Stronger fix:** use a prospectively specified simulation-based precision or power analysis. **Test:** estimate variance from this pilot, define a meaningful effect independently, then simulate design operating characteristics. **Decision:** no confirmatory claim from current sample sizes.

### 15. Independent replicate is the seed block

**Problem:** generations and agents within a run are dependent. **Why / threat:** counting them as independent would severely understate uncertainty. **Minimum fix:** analyze run-level endpoints and paired seed-block contrasts. **Stronger fix:** replicate with independently generated initial populations and graph realizations in a second implementation. **Test:** inspect analysis code to ensure resampling occurs over seeds only. **Decision:** do not use organisms or generations as inferential units.

### 16. Independent implementation is absent

**Problem:** only one codebase has generated the results. **Why / threat:** a shared implementation error can survive unit tests. **Minimum fix:** publish equations, code, seeds, manifests, and deterministic checks. **Stronger fix:** have a second researcher implement the specification without copying code and compare outputs. **Test:** independent small-case transitions, selection distributions, metrics, and replicated run-level outcomes. **Decision:** disagreements stop any replication claim until resolved.

### 17. Legacy data have provenance conflicts

**Problem:** the available historical package contains one traceable 16-run pilot and a second variable-length 62,370-row file with a mismatched source hash and manifest. **Why / threat:** data without matching code and seeds cannot be independently reproduced. **Minimum fix:** exclude the inconsistent file and state why. **Stronger fix:** recover its exact generating source and logs. **Test:** compare code hash, seed list, row counts, and generation ranges. **Decision:** use only artifacts whose run manifest and generating source reconcile; do not represent the missing 200-run claim as observed.

### 18. Literature gap is not verified

**Problem:** the current literature audit is focused, not systematic. **Why / threat:** related environment, network, novelty, and OEE studies may already address the proposed combination. **Minimum fix:** state the gap as unverified and avoid a priority claim. **Stronger fix:** database searches, citation chaining, and independent two-person screening with a logged search protocol. **Test:** compare the exact interventions, persistence definition, horizon, and controls against nearest studies. **Decision:** make a novelty claim only after the systematic search supports it.

### 19. \(\tau_A\) and the timescale ratio are not calibrated

**Problem:** no independent adaptive-recovery estimate exists. **Why / threat:** a ratio \(\tau_E/\tau_A\) could be circular or unidentifiable. **Minimum fix:** do not calculate it in this study. **Stronger fix:** define recovery independently, estimate it in a dedicated calibration design, and carry uncertainty/censoring into later predictions. **Test:** evaluate recovery under known environmental switches without using the novelty endpoint. **Decision:** analyze the ratio only if \(\tau_A\) is identifiable and repeatable.

### 20. Held-out prediction has not been performed

**Problem:** the model has not predicted unseen conditions before their outcomes were run. **Why / threat:** explanatory summaries may fit the conditions already inspected. **Minimum fix:** make no predictive-validity claim. **Stronger fix:** freeze code and parameters, timestamp predictions for held-out periods and graph conditions, then score calibration and error. **Test:** run held-out conditions only after predictions are committed. **Decision:** a failed prediction remains a result and cannot be retroactively tuned into a pass.

### 21. Periodic recurrence is logged but not experimentally isolated

**Problem:** the environment is periodic, but no aperiodic schedule with matched change count and magnitude was run. **Why / threat:** a recurring environmental cycle could itself produce recurring ecological trajectories. **Minimum fix:** ensure recurrence is not counted as a new phenotype and report reappearance and census-state recurrence separately. **Stronger fix:** compare periodic and shuffled/jittered schedules with equal change counts and amplitudes. **Test:** compare event persistence and recurrence intervals under matched periodic and aperiodic schedules. **Decision:** until that control exists, interpret the present result as conditional on periodic complementation; do not attribute it to environmental rate alone.

## Resolved software gates

The current implementation passed synthetic lineage checks, mutation-rate calibration, graph degree/connectivity checks, exact replay, no-mutation discovery checks, neutral-history invariance, and checksum/generation/event audits. These gates validate specific software properties. They do not resolve the scientific limitations above.
