#!/usr/bin/env python3
"""Validate run manifests, raw CSV integrity, and complete generation coverage."""
import argparse
import csv
import hashlib
import json
from pathlib import Path

FINAL_STAGES = ("artifact_controls", "mutation_opportunity", "demographic_opportunity", "primary_factorial", "representation_robustness", "long_horizon")


def sha256_file(path):
    digest = hashlib.sha256()
    with open(path, "rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def read_csv(path):
    with open(path, newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle))


def audit(data_dir, output_path):
    data_dir = Path(data_dir)
    stage_results = {}
    errors = []
    model_hash = sha256_file(Path(__file__).with_name("model.py"))
    runner_hash = sha256_file(Path(__file__).with_name("run_experiments.py"))
    for stage in FINAL_STAGES:
        stage_dir = data_dir / stage
        manifest_path = stage_dir / "manifest.json"
        if not manifest_path.exists():
            errors.append("missing manifest for " + stage)
            continue
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        if manifest.get("model_sha256") != model_hash:
            errors.append("model source hash mismatch for " + stage)
        if manifest.get("runner_sha256") != runner_hash:
            errors.append("runner source hash mismatch for " + stage)
        planned = manifest["planned_runs"]
        summaries = read_csv(stage_dir / "run_summary.csv")
        if len(planned) != len(summaries):
            errors.append("planned and summarized run counts differ for " + stage)
        config_by_id = {row["run_id"]: row for row in planned}
        summary_by_id = {row["run_id"]: row for row in summaries}
        if set(config_by_id) != set(summary_by_id):
            errors.append("run IDs differ from the manifest for " + stage)
        for filename, expected_hash in manifest["raw_files"].items():
            actual_hash = sha256_file(stage_dir / filename)
            if actual_hash != expected_hash:
                errors.append("checksum mismatch: {}/{}".format(stage, filename))
        timeseries_rows = read_csv(stage_dir / "timeseries.csv")
        generations_by_run = {}
        duplicate_censuses = 0
        for row in timeseries_rows:
            run_id = row["run_id"]
            generation = int(row["generation"])
            bucket = generations_by_run.setdefault(run_id, set())
            if generation in bucket:
                duplicate_censuses += 1
            bucket.add(generation)
        if duplicate_censuses:
            errors.append("duplicate generation records in " + stage)
        for run_id, config in config_by_id.items():
            expected = int(config["generations"])
            observed = generations_by_run.get(run_id, set())
            if len(observed) != expected + 1 or not observed or min(observed) != 0 or max(observed) != expected:
                errors.append("generation coverage incomplete for {}/{}".format(stage, run_id))
            if run_id not in summary_by_id:
                continue
            summary = summary_by_id[run_id]
            if int(summary["seed"]) != int(config["seed"]) or int(summary["generations"]) != expected:
                errors.append("seed or horizon mismatch for {}/{}".format(stage, run_id))
            for field in ("population", "network", "representation", "selection", "environment"):
                if str(summary[field]) != str(config[field]):
                    errors.append("{} mismatch for {}/{}".format(field, stage, run_id))
            if float(summary["mutation_rate_per_bit"]) != float(config["mutation_rate"]):
                errors.append("mutation rate mismatch for {}/{}".format(stage, run_id))
            if int(summary["degree"]) != 4 or int(summary["connected"]) != 1 or int(summary["edges"]) != 2 * int(summary["population"]):
                errors.append("graph opportunity invariant failed for {}/{}".format(stage, run_id))
        event_rows = read_csv(stage_dir / "events.csv")
        events_by_run = {}
        seen_event_codes = set()
        for event in event_rows:
            run_id = event["run_id"]
            key = (run_id, event["phenotype_code"])
            if key in seen_event_codes:
                errors.append("duplicate first-seen phenotype event in {}/{}".format(stage, run_id))
            seen_event_codes.add(key)
            events_by_run.setdefault(run_id, []).append(event)
            if int(event["followup_steps"]) > 40 or int(event["present_steps"]) > int(event["followup_steps"]):
                errors.append("invalid event follow-up for {}/{}".format(stage, run_id))
            if event["right_censored"] == "0" and event["persistent"] not in ("0", "1"):
                errors.append("complete event lacks binary persistence status in " + stage)
            if event["right_censored"] == "1" and event["persistent"] != "":
                errors.append("censored event was assigned a persistence status in " + stage)
        for run_id, summary in summary_by_id.items():
            events = events_by_run.get(run_id, [])
            complete = [event for event in events if event["right_censored"] == "0"]
            persistent = sum(int(event["persistent"]) for event in complete)
            censored = sum(int(event["right_censored"]) for event in events)
            if len(complete) != int(summary["eligible_persistence_events"]):
                errors.append("eligible event count mismatch in {}/{}".format(stage, run_id))
            if persistent != int(summary["persistent_innovations"]):
                errors.append("persistent event count mismatch in {}/{}".format(stage, run_id))
            if censored != int(summary["censored_persistence_events"]):
                errors.append("censored event count mismatch in {}/{}".format(stage, run_id))
        stage_results[stage] = {"planned_runs": len(planned), "summarized_runs": len(summaries), "timeseries_rows": len(timeseries_rows), "event_rows": len(event_rows), "checksums_verified": len(manifest["raw_files"]), "all_runs_have_complete_generation_coverage": not any(error.startswith("generation coverage incomplete for " + stage + "/") for error in errors)}
    gate_path = data_dir / "artifact_controls" / "gate_report.json"
    gate = json.loads(gate_path.read_text(encoding="utf-8")) if gate_path.exists() else {}
    if not gate.get("main_factorial_authorized_by_gate", False):
        errors.append("artifact-control gate report missing or failed")
    result = {"status": "passed" if not errors else "failed", "stages": stage_results, "artifact_control_gate_passed": bool(gate.get("main_factorial_authorized_by_gate", False)), "errors": errors}
    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    if errors:
        raise RuntimeError("Data audit failed: " + "; ".join(errors[:8]))
    print(json.dumps(result, indent=2))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--data", default="data")
    parser.add_argument("--out", default="analysis/data_audit.json")
    args = parser.parse_args()
    audit(args.data, args.out)


if __name__ == "__main__":
    main()
