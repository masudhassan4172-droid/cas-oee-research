# Frozen protocol, version 0.2.0

**Status:** Set before the replacement simulations. This local protocol is not externally registered and the study is exploratory rather than confirmatory.

## Question and primary hypothesis

**Primary question:** Does environmental switching period interact with degree-matched interaction graph in predicting lineage-persistent first-seen phenotype discoveries in this finite model?

**PROPOSED hypothesis:** The environment-by-graph contrast may differ across switching periods. No direction or critical regime is assumed. The primary design permits a null result.

## Primary outcome and contrast

The outcome is persistent first-seen phenotype discoveries per 1,000 births. A phenotype is first-seen when absent from every prior census. Its original carrier cohort receives a lineage tag; the event is persistent if a descendant expressing that same phenotype is present in at least 32 of the next 40 censuses. Unrelated recurrence is excluded. The initial census is the baseline. Incomplete follow-up is censored.

The primary contrast is a seed-blocked difference-in-differences:

\[
[(Y_{fast,ring}-Y_{static,ring})-(Y_{fast,rewired}-Y_{static,rewired})].
\]

Slow and medium contrasts are secondary. Effect sizes and intervals are reported at the seed-block level. There are no organism-level or generation-level inferential degrees of freedom and no significance threshold drives interpretation.

## Staged workflow and matrix

| Stage | Conditions | Independent seeds | Generations | Purpose |
|---|---|---:|---:|---|
| Measurement / implementation validation | Synthetic lineage cases; mutation calibration; graph and replay checks | Fixed validation streams | 60 for replay | Verify measurement logic and exact implementation behavior |
| Artifact controls | No mutation: static/fast × ring/rewired; neutral selection: same 2 × 2 | 4 per cell | 300 | Require zero post-baseline novelty without mutation and identical genotype histories under neutral treatment labels |
| Mutation opportunity | \(\mu\in\{0.001,0.002,0.01\}\), static/fast, rewired graph | 6 per cell | 500 | Measure dependence on mutation supply |
| Demographic opportunity | \(N\in\{50,100,200\}\), static/fast, rewired graph | 6 per cell | 500 | Report absolute and birth-normalized event rates |
| Primary factorial | Static/200/50/10 switching period × ring/rewired graph | 12 per cell | 1,000 | Estimate environment, graph, and interaction contrasts |
| Representation robustness | Binary parity map; static/fast × both graphs | 4 per cell | 2,000 | Expose descriptor dependence and finite-space saturation |
| Long horizon | Primary map; static/fast × both graphs | 6 per cell | 5,000 | Observe whether coverage and discovery trajectories approach saturation |

All graph treatments have degree four, are connected, and have equal edge and encounter counts. The main design uses a fixed census of 100 and per-bit mutation probability 0.002. The alternate representation changes both phenotype decoding and the environmental-match dimensionality; it is a model-level representation sensitivity, not a measurement-only re-scoring of identical trajectories. The exact seeds and hashes are in each stage manifest.

Recurrence is controlled at the measurement level: a phenotype is registered only at its first-ever appearance, unrelated rediscovery does not count as descendant persistence, and reappearance and exact census-state recurrence are logged separately. A matched aperiodic environment schedule is not included, so periodic environmental cycles remain a possible mechanism.

## Gates

The primary factorial is not launched unless all of these hold:

1. Synthetic lineage examples distinguish tagged descendants from unrelated reappearance and right-censor incomplete horizons.
2. The mutation operator's observed per-bit rate is within five binomial standard errors of its specified rate.
3. Graph checks establish connectedness, degree four, and equal edges.
4. Same-code/same-seed replay is exact.
5. In the no-mutation control, there are no post-baseline genotype or phenotype discoveries.
6. In the neutral-selection control, matched seeds produce identical genotype histories across environment and graph labels.

Failure stops the primary experiment and requires a code/protocol version change. It cannot be repaired by changing a threshold after inspecting main results.

## Interpretation boundaries

- The finite 6,561-state phenotype representation saturates by construction; the long run can show whether it saturated within the observed horizon, not establish unbounded novelty.
- The 32-bit genome is finite. No finite trajectory demonstrates mathematical unboundedness.
- Persistent novelty under this operational definition is not sufficient evidence for OEE, expansive innovation, or transformational innovation.
- The switching rate does not establish a timescale mechanism. \(\tau_A\) and \(\tau_E/\tau_A\) are not analyzed here; adaptive recovery must first be independently calibrated.
- Network effects are conditional on this pair of degree-matched graphs and do not generalize to “network structure” as a whole.
- All primary results remain exploratory until independent implementation and replication.
