# Environmental dynamics, interaction structure, and persistent novelty

This repository contains a reproducible computational study of whether environmental switching and degree-matched interaction graphs alter the appearance and descendant persistence of first-seen phenotypes in a finite evolving population.

**Study status:** an exploratory, preregistered-in-spirit computational pilot. The protocol and primary contrast are frozen before the new runs; there is no independent second implementation, external preregistration, or confirmatory replication. The system is finite and cannot demonstrate mathematically unbounded evolution or open-ended evolution (OEE).

## Research question

Does environmental switching period interact with degree-matched interaction graph in predicting the rate of first-seen phenotypes that remain present in their descendant lineage for at least 32 of the next 40 generations, after explicitly measuring mutation and population opportunity?

The primary model studies **exploratory novelty within a fixed phenotype space**. Its primary phenotype map has 6,561 possible states. It does not implement expansive or transformational novelty.

## Quick start

Requires Python 3.9 or later and the standard library only.

```sh
python3 -m unittest -v
python3 run_experiments.py --stage validate --out data
python3 run_experiments.py --stage all --out data
python3 audit_data.py --data data --out analysis/data_audit.json
python3 analyze.py --data data --out analysis
python3 confirmatory_power_plan.py --input analysis/seed_blocked_interaction_contrasts.csv --out analysis
```

The full experiment runs approximately 240 independent trajectories across artifact controls, mutation and demographic controls, a 4 × 2 primary factorial, an alternate representation, and a 5,000-generation horizon. The script stops before the primary factorial if the measurement or artifact-control gates fail. Raw stage outputs are never overwritten; use a new output directory for a new run.

The validation stage checks measurement rules, mutation-rate calibration, graph degree/connectivity, baseline exclusion, and exact same-seed reproducibility. GitHub Actions runs software validation and verifies the committed raw-data manifests/checksums; it does not rerun the full research simulation.

## Repository map

- `model.py` — transition rules, graph construction, phenotype decoding, lineage tracking, and run-level measurements.
- `run_experiments.py` — frozen staged experiment matrix, seed assignment, output manifests, and artifact-control gates.
- `analyze.py` — seed-level summaries, bootstrap uncertainty, effect-size contrasts, and vector figures.
- `audit_data.py` — stage-manifest, checksum, seed, generation, and event-log audit.
- `test_model.py` — deterministic software and metric checks.
- `MODEL_SPEC.md` — mathematical and algorithmic specification.
- `PROTOCOL.md` — hypotheses, endpoints, treatment matrix, gates, and claim boundaries.
- `ANALYSIS_AMENDMENT.md` — transparent post-run correction for right-censored persistence events.
- `RESEARCH_AUDIT.md` — forensic audit of the available files and focused literature audit.
- `RISK_REGISTER.md` — ranked validity threats, tests, and decision rules.
- `CONFIRMATORY_PROTOCOL_v1_DRAFT.md` — proposed follow-up estimand, gates, treatment matrix, and stopping rules; not externally preregistered and not yet run.
- `confirmatory_power_plan.py` — transparent sample-size sensitivity calculation from pilot seed-block variability.
- `DATA_DICTIONARY.md` — fields and units for generated CSVs.
- `data/` — raw timeseries, event logs, seed-level outcomes, and exact run manifests.
- `analysis/` — derived tables, figures, and exploratory interpretation.

## Reproducibility

Each simulation seed identifies one independent run. In the factorial experiment, treatment arms with the same seed share initial genomes and starting environment; stochastic evolutionary streams are treatment-specific. The analysis uses the replicate/seed block as its inferential unit. Generations and organisms are not treated as independent replicates.

Every data stage records its complete configuration, seeds, Python version, source hashes, and output-file hashes in `manifest.json`. The random generator is Python's `random.Random`; exact bitwise replay requires the recorded source and a compatible Python runtime.

The report labels claims as **PROPOSED**, **OBSERVED**, **INTERPRETED**, **HYPOTHESIZED**, or **NOT SUPPORTED**. No significance-driven tuning is allowed. The timescale ratio is not analyzed until adaptive recovery time is independently calibrated.

## Confirmatory follow-up

The draft includes a conditional 50-block example if an absolute interaction of 0.02 persistent events per 1,000 eligible births is independently justified. It also shows the much larger allocation implied by the pilot's smaller point estimate. No final sample size is selected, and no confirmatory runs may start until the effect/precision target is justified, the code and seeds are frozen, an independent implementation review passes, and the protocol is externally registered. No follow-up outcomes are included in this package.

## GitHub

The private GitHub repository distributes versioned ZIP packages with a landing-page README. The GitHub Actions workflow is included inside each full source archive and runs after extraction into a normal source-tree checkout; it is not active at the archive-only repository root. No software license has been selected.
