# Model specification

## Scope

**PROPOSED / FROZEN FOR THIS RUN.** A finite, synchronous, fixed-census evolutionary population is used to test whether environmental switching and two degree-matched graph structures alter descendant-persistent phenotype discovery. The system has no expanding genome, no endogenous rule change, and no unbounded phenotype space. It is not a model of OEE in the strong or mathematical sense.

## State

At generation \(t\), there are \(N\) individuals. Individual \(i\) carries a 32-bit genotype \(g_i(t)\in\{0,1\}^{32}\), a lineage-tag bitset used only for measurement, and a derived phenotype. The baseline is \(N=100\); population-size controls use \(N\in\{50,100,200\}\).

The primary genotype-to-phenotype map divides the genome into four 8-bit loci. Each phenotype coordinate is the number of 1 bits in one locus:

\[
p_{ik}(t)=\operatorname{popcount}(g_i(t)_{8k:8k+8})\in\{0,1,\ldots,8\},\quad k=1,\ldots,4.
\]

Thus the descriptor space contains exactly \(9^4=6{,}561\) possible phenotypes, with many genotypes mapping to the same phenotype. The finite genotype space contains \(2^{32}\) genomes. An alternative representation used only for robustness divides the genome into eight 4-bit blocks and uses each block's parity, yielding \(2^8=256\) phenotypes.

## Environment and fitness

The environment is a target vector \(e(t)\in\{0,\ldots,8\}^4\), drawn uniformly per coordinate at \(t=0\). The static condition holds this vector fixed. At switching period \(P\in\{200,50,10\}\), the target is complemented, \(e_k\leftarrow8-e_k\), at generations \(P,2P,3P,\ldots\). The robustness representation uses a binary target and bitwise complementation.

Environmental match is

\[
q_i(t)=1-\frac{1}{4}\sum_{k=1}^{4}\frac{|p_{ik}(t)-e_k(t)|}{8}.
\]

The graph is fixed during each run. Every undirected edge is a pairwise resource contest: the individual with higher \(q\) receives 1, the other 0, and ties split 0.5 each. With degree four, local contest success is \(c_i(t)=\frac14\sum_{j\sim i}a_{ij}(t)\). Ecological fitness is

\[
w_i(t)=0.25+q_i(t)+0.5c_i(t).
\]

The novelty metrics, phenotype richness, and complexity are absent from fitness. A neutral-control condition sets every \(w_i=1\).

## Graph treatment

Both graphs are simple, undirected, connected, 4-regular graphs. The structured graph is a ring lattice linking each node to its two nearest neighbors on each side. The comparison graph starts from that same lattice and undergoes \(20|E|\) accepted degree-preserving double-edge swaps, rejecting any swap that creates a duplicate edge, self-loop, or disconnected graph. This is a **rewired regular graph**, not a uniform sample from all 4-regular graphs. Every individual has four encounters per generation and every graph has \(2N\) edges, so total encounter opportunity is exactly matched. Clustering and path structure are allowed to differ and are recorded; this contrast does not isolate one graph statistic.

## Reproduction and mutation

Parents are drawn independently with replacement from the current census with probability \(w_i/\sum_j w_j\). Exactly \(N\) offspring form the next census. Each of the 32 bits is independently flipped with probability \(\mu\), baseline \(\mu=0.002\) per bit per offspring. The mutation operator samples geometric gaps between flips, which is distributionally equivalent to independent per-bit Bernoulli mutation. There is no recombination, variable population size, explicit resource stock, spatial coordinate, learning, cooperation, or network rewiring.

One generation consists of observing the current census, calculating match and contests, selecting \(N\) parents with replacement, mutating the offspring, and replacing the census synchronously.

## Novelty and persistence

Generation 0 defines the baseline and contributes no novelty event. A first-seen phenotype is a descriptor absent from every earlier census and present in the current census. It is registered once globally; recurrence does not create a second novelty event.

At first detection, all current carriers receive a unique bit tag for that phenotype. Descendants inherit those tags even if their phenotype changes. For the following 40 censuses, a phenotype is present in its origin lineage when at least one tagged descendant expresses the same phenotype. An event is classified as persistent if this occurs in at least 32 of those 40 censuses. A rediscovery by an untagged lineage does not count. Events without 40 complete follow-up censuses are right-censored and excluded from the persistence numerator and denominator.

The primary run-level endpoint is

\[
1000\times\frac{\text{persistent first-seen phenotype events}}{N\times T},
\]

where \(T\) is the number of reproduction cycles (birth opportunities per run are \(N T\)). Report the number of eligible events and censored events alongside this rate. Secondary measures include genotype discoveries, phenotype coverage, richness, Shannon entropy, phenotype reappearance after absence, exact phenotype-abundance-state recurrence, mean environmental match, and realized mutation counts.

## Randomness and pairing

Genomes are initialized uniformly from the 32-bit space. SHA-256-derived seeds create separate deterministic streams for initial genomes, starting environment, graph construction, and evolution. In a factorial seed block, treatment arms share initial genomes and starting environment, while the evolutionary stream is treatment-specific. The neutral artifact control intentionally uses a shared evolutionary stream across treatment labels so any environment/network dependence would be an implementation leak. Independent seed blocks are the inferential units.
