# Environmental switching and interaction-graph structure in persistent phenotype discovery: a finite computational experiment

**Manuscript status:** empirical exploratory draft based on the included simulation outputs. This is not submission-ready: the focused literature audit is not systematic, the censoring correction was made after inspecting results, the seed count is modest, and independent implementation is pending.

## Abstract

Open-ended evolution (OEE) is not established by observing new states in a finite simulation. We tested a narrower question: whether environmental switching period and degree-matched interaction graph jointly predict first-seen phenotypes that persist in their descendant lineage in a finite evolutionary model. The model used a fixed census of 100 agents, 32-bit genomes, a four-trait phenotype map with 6,561 possible states, ecological selection, per-bit mutation probability 0.002, and connected degree-four ring or rewired-regular interaction graphs. Before the main factorial, measurement checks and artifact controls tested lineage attribution, mutation calibration, graph opportunity, no-mutation behavior, and a neutral-selection null. The staged study completed 240 planned trajectories, including 96 primary runs (12 seed blocks in each of eight cells), mutation and population-size controls, an alternate 256-state representation, and 5,000-generation runs. The fast-versus-static difference-in-differences for persistent discoveries was −0.0078 per 1,000 eligible births (95% seed-block bootstrap interval −0.0234 to 0.0078; 12 blocks). Condition means were highest under the 200-generation switching period, but the interaction estimate was imprecise. The alternate representation reached complete descriptor coverage in fast conditions, while primary-map long runs remained far from coverage saturation. A post-run correction excluded the final 40 generations from eligible exposure because their events could not complete persistence follow-up; original as-frozen estimates are retained. These outputs provide exploratory evidence about this implementation only. They do not demonstrate OEE, an unbounded process, or a general network effect.

**Keywords:** artificial life; evolutionary novelty; environmental switching; interaction networks; lineage persistence; computational experiment; open-ended evolution

## 1. Introduction

Open-ended evolution is an important but contested target in artificial life. Proposed frameworks distinguish ongoing novelty, complexity growth, ecological change, and other behavioral hallmarks, and they do not reduce to a single observation of new states. Taylor distinguishes exploratory novelty within a defined behavior space from expansive and transformational novelty that changes or extends the space itself. The fixed genotype and phenotype rules studied here address exploratory novelty only. The MODES toolbox provides several complementary measures of evolving systems; this study's custom lineage-persistence endpoint should be interpreted as one narrow outcome rather than a substitute for those measures. Formal accounts of innovation and unbounded evolution also rely on counterfactual comparisons that this model does not implement. [1–4]

Environmental variation can alter adaptive paths and predictability, while ecological and spatial structure can leave complex evolutionary signatures. These results make it inappropriate to claim that environmental dynamics or networks are new topics. A narrower, still unverified question is whether their joint manipulation changes a lineage-attributed persistent-phenotype outcome after mutation and opportunity controls in this particular minimal model. The present work does not claim that this combination is unprecedented; a systematic literature and citation audit remains necessary before making any novelty-of-contribution claim. [5,6]

We therefore ask: **Does environmental switching period interact with degree-matched interaction graph in predicting first-seen phenotype discoveries that persist in their descendant lineage, after measuring mutation and demographic opportunity?** The proposed hypothesis is that the environment-by-graph contrast may depend on switching period. We specified no preferred direction or critical regime. The central alternative is that apparent novelty depends on mutation supply, finite representation, lineage loss, or differences in opportunity.

## 2. Methods

### 2.1 Model

Each generation contains \(N=100\) agents with 32-bit genomes. The primary map divides each genome into four 8-bit loci and maps each locus to its number of 1 bits, yielding four integer traits in \(\{0,\ldots,8\}\) and a finite phenotype space of \(9^4=6{,}561\) states. The map is many-to-one. A robustness arm uses eight 4-bit parity traits and a 256-state phenotype space.

The environment is a four-trait target vector. Its initial coordinates are sampled uniformly from 0 through 8. It is static or complemented at fixed intervals of 200, 50, or 10 generations. Match is one minus mean absolute trait distance scaled by eight. Each graph edge represents a pairwise resource contest: the better-matching agent receives one point and the other zero; ties split the point. Local contest success is each agent's mean edge payoff. Fitness is \(w_i=0.25+q_i+0.5c_i\), where \(q_i\) is environmental match and \(c_i\) local contest success. Novelty, diversity, and complexity do not enter fitness. The fixed census is reproduced by Wright–Fisher sampling with replacement, followed by independent per-bit mutation at baseline \(\mu=0.002\). There is no recombination, explicit resource stock, spatial coordinate, variable population size, learning, cooperation, or genome expansion.

The ring graph links each node to its two nearest neighbors on each side. The comparison is a connected degree-four graph formed by 20 accepted degree-preserving edge swaps per edge from the ring. Thus the comparison is not a uniform random sample from all regular graphs. Both conditions provide exactly four contests per individual and \(2N\) edges per census. They can differ in clustering and path structure, so the treatment identifies a contrast between these two graph constructions, not an isolated effect of one network statistic.

### 2.2 Novelty, recurrence, and persistence

Generation zero defines the baseline and is not a novelty event. A phenotype first appearing after the baseline is registered once, at its first census. Phenotype reappearance after absence and recurrence of an exact phenotype-abundance census state are measured separately.

At first detection, all current carriers receive an event-specific lineage tag. Descendants inherit that tag even if their phenotype changes. For the next 40 censuses, an event is present when at least one tagged descendant expresses the event's original phenotype. The frozen persistence rule classifies an event as persistent when present in at least 32 of those 40 censuses. A later appearance by an untagged lineage does not count. Events without 40 follow-up censuses are right-censored.

The frozen version 0.2 endpoint divided persistent events by all \(NT\) births. After inspecting the event timing, we identified that this denominator included the final 40 generations, which cannot produce mature persistence observations. We therefore retain the as-frozen rate and report a transparent post-run correction: count events originating no later than generation \(T-40\), then divide by \(N(T-40)\), the births in eligible generations 1 through \(T-40\). This reanalysis is exploratory, not a preregistered confirmatory estimand. The raw data and original endpoint were not changed. Full details are in `ANALYSIS_AMENDMENT.md`.

### 2.3 Experimental stages

Measurement validation used synthetic lineage cases, a 1.6-million-bit mutation-rate calibration, graph checks at \(N=50\) and 100, baseline exclusion, and exact same-seed replay. Artifact controls included 16 no-mutation runs and 16 neutral-selection runs (four seeds per environment × graph cell, 300 generations, \(N=60\)). The no-mutation control required no post-baseline genotype or phenotype discoveries. In the neutral control, matched seeds required identical genotype histories across environment and graph labels. The primary experiment proceeded only after both gates and the graph degree/connectivity gate passed.

Mutation controls crossed per-bit rates 0.001, 0.002, and 0.01 with static and fast environments (six runs per cell, 500 generations, rewired graph). Demographic controls crossed \(N=50,100,200\) with static and fast environments (six runs per cell, 500 generations, rewired graph). The primary factorial crossed four environmental schedules with two graphs (12 seed blocks per cell; 1,000 generations). Representation/model-sensitivity runs used the parity map in static and fast conditions across both graphs (four runs per cell; 2,000 generations). This intervention changed both the phenotype map and the dimensionality of the match target; it is not a measurement-only re-scoring of identical genotype histories. Long-horizon runs used the primary map in static and fast conditions across both graphs (six runs per cell; 5,000 generations). This totals 240 planned trajectories.

Matched arms in a seed block share initial genomes and starting environment, but use treatment-specific evolutionary random streams. Each independently seeded run is a replication unit; individuals and serial generations are not inferential units. The primary contrast is the seed-blocked difference-in-differences \([(Y_{fast,ring}-Y_{static,ring})-(Y_{fast,rewired}-Y_{static,rewired})]\). Slow and medium contrasts are secondary. We report mean effects and percentile bootstrap intervals over seed blocks (5,000 resamples) without p-values or a significance threshold. With 12 seed blocks per cell, all primary findings are exploratory.

### 2.4 Reproducibility

The project uses standard-library Python, explicit seed streams, raw generation-level CSV, phenotype-event logs, seed-level outcomes, and per-stage manifests with code and output hashes. The initial gate code had two reporting defects; those completed control attempts are retained in separate folders and excluded from analysis. The corrected artifact-control stage passed before the primary factorial ran. Full data and implementation are included in the accompanying reproducibility package.

## 3. Results

### 3.1 Validation and controls

All 11 measurement checks passed, including positive descendant persistence, rejection of unrelated reappearance, threshold boundaries, right-censoring, baseline exclusion, and the expected phenotype-space sizes. Across 1,600,000 bit opportunities at nominal \(\mu=0.002\), the observed per-bit rate was 0.001962, within the prespecified five-standard-error tolerance. Ring and rewired graphs passed connectedness, degree-four, and edge-count checks. Same-code, same-seed replay produced identical outcomes.

In the 16 no-mutation runs, there were no post-baseline genotype or phenotype discoveries. In the 16 neutral-selection runs, each matched seed produced identical genotype histories across the environment and graph labels. The artifact-control gate passed. These checks validate the implementation and measurement rules under their designed conditions; they do not validate biological realism.

### 3.2 Primary factorial

Table 1 reports the post-run eligible-exposure rate. The mean was 0.0304 persistent events per 1,000 eligible births in both static graph conditions, 0.1198 and 0.1302 under the 200-generation schedule, 0.0799 and 0.0833 under the 50-generation schedule, and 0.0582 and 0.0503 under the 10-generation schedule. Each cell has 12 independent seed blocks. The slow schedule had the largest observed mean, but this pattern does not establish a mechanism or a general optimum.

**Table 1. Persistent first-seen phenotype events per 1,000 eligible births.** Intervals are 95% percentile bootstrap intervals over 12 run-level seed blocks. These are exploratory estimates.

| Environment | Graph | Mean | 95% bootstrap interval |
|---|---|---:|---:|
| Static | Rewired regular | 0.0304 | 0.0217–0.0391 |
| Static | Ring | 0.0304 | 0.0217–0.0382 |
| Switch every 200 generations | Rewired regular | 0.1198 | 0.0955–0.1458 |
| Switch every 200 generations | Ring | 0.1302 | 0.1085–0.1536 |
| Switch every 50 generations | Rewired regular | 0.0799 | 0.0642–0.0964 |
| Switch every 50 generations | Ring | 0.0833 | 0.0616–0.1102 |
| Switch every 10 generations | Rewired regular | 0.0582 | 0.0408–0.0764 |
| Switch every 10 generations | Ring | 0.0503 | 0.0339–0.0694 |

For the prespecified fast-versus-static interaction contrast, the difference-in-differences was −0.0078 events per 1,000 eligible births (95% seed-block bootstrap interval −0.0234 to 0.0078; 12 blocks). The corresponding slow-versus-static estimate was 0.0104 (−0.0113 to 0.0356), and the medium-versus-static estimate was 0.0035 (−0.0226 to 0.0286). Each interval spans zero. The data do not resolve an environment-by-graph interaction with this sample size and model.

**Figure 1.** Seed-level means and bootstrap intervals are in `analysis/figure_primary_factorial.svg`; the numerical table is `analysis/primary_condition_summary.csv`.

### 3.3 Mutation and demographic opportunity

In the six-run mutation sensitivity cells, the mean number of first-seen phenotypes increased with mutation rate. Under static conditions it rose from about 111 events at \(\mu=0.001\) to 751 at \(\mu=0.01\); under fast switching it rose from about 191 to 1,183. The eligible-exposure persistent-event rate did not rise in parallel: at \(\mu=0.01\), it was 0.0217 per 1,000 eligible births under static conditions and zero in the six fast runs. These controls show that the raw discovery count is strongly sensitive to mutation opportunity in this implementation. The small cell sizes make the endpoint summaries descriptive.

In the six-run population-size controls, absolute persistent-event counts varied less than the per-birth rates under static conditions: mean counts were 2.17, 2.33, and 2.33 for \(N=50,100,200\), while rates were 0.0942, 0.0507, and 0.0254 per 1,000 eligible births. Under fast switching, mean counts rose from 2.83 to 4.50 while rates fell from 0.1232 to 0.0489. This demonstrates why absolute discovery counts and opportunity-normalized rates answer different questions; it does not remove all demographic effects.

### 3.4 Representation and long horizon

In the alternate 256-state parity representation, fast-environment runs reached 100% phenotype-descriptor coverage by 2,000 generations (four runs per graph). Static runs averaged approximately 64% coverage. The primary 6,561-state map did not approach saturation in the 5,000-generation runs: mean coverage was 4.9% and 5.0% in static conditions and 11.5% and 11.4% under fast switching for rewired and ring graphs, respectively; none of the 24 long runs reached 95% coverage. The different outcomes across representations show that coverage and discovery trajectories depend on the chosen descriptor map. The long horizon does not establish indefinite novelty.

The 32-of-40 persistence rule is sensitive to threshold, as expected. Across thresholds of 20, 32, and 40 presences, the observed slow-condition rate remained highest, while exact rates changed substantially. The threshold table is reported in `analysis/persistence_threshold_sensitivity.csv`; no threshold was selected based on a preferred interaction result. The first-seen registry, lineage tags, reappearance counts, and census-state recurrence metric control recurrence as a measurement artifact. A matched aperiodic environment schedule was not run, so recurring environmental cycles remain a possible ecological mechanism.

## 4. Discussion

The main result is an exploratory estimate of the environment-by-graph contrast, not evidence for a general causal mechanism. The primary fast-versus-static interaction interval includes zero, as do the secondary slow and medium interaction intervals. The two graph conditions had exactly matched degree and encounter counts, yet differed in other graph properties by design. This experiment therefore cannot identify a unique topological feature or establish that networks generally alter persistent novelty.

The observed mutation and census controls show that novelty counts depend on opportunity and that the choice of normalization matters. The alternate representation saturated under fast switching even though the primary map remained far from saturation at 5,000 generations. These findings support treating genotype novelty, phenotype novelty, persistence, recurrence, and descriptor coverage as distinct measurements. They also argue against describing the finite trajectories as OEE. Taylor's distinction between exploratory and expansive/transformational novelty is directly relevant: a fixed map explores a state space already defined by the model. MODES and Tokyo Type 1 procedures further motivate broader evidence on adaptive novelty, ecological potential, complexity, and long-term trends before any OEE claim. [1,2,4]

The post-run eligible-exposure correction addresses the final-40-generation censoring problem, but it was made after first inspecting outputs. We retained and reported the original denominator and labeled the corrected reanalysis as exploratory. A future confirmatory study should freeze an eligible-origin window or use a prespecified time-to-persistence analysis before observing outcomes.

Several limitations prevent strong claims. The genome and phenotype spaces are finite. The primary map is not behaviorally rich and the fitness function rewards environmental match rather than novelty. Resource competition is represented as local pairwise contests without a resource stock. Population size is fixed except in separate sensitivity runs. The two graphs match degree but differ in clustering and path structure; there is no independent manipulation of spatial embedding. The primary factorial has 12 seed blocks per cell, the control sensitivities have six, and the alternative map has four. That map changes the fitness target as well as the descriptor, so it does not isolate representation as a measurement operation. The bootstrap intervals are descriptive with these small samples. Only one implementation has been run; a second researcher should implement the frozen equations independently. The source audit is focused rather than systematic, so the novelty of the research contribution has not been verified.

The timescale ratio \(\tau_E/\tau_A\) was not analyzed. Adaptive recovery time was not independently calibrated, and a dimensionless ratio computed from the same novelty series would not provide independent evidence. No criticality, phase transition, adaptive novelty, expansive innovation, transformational innovation, unbounded evolution, or OEE is demonstrated.

## 5. Conclusion

In this finite model, environmental schedule means differed descriptively, while the estimated environment-by-graph interaction was small and uncertain across 12 seed blocks. Mutation and census size changed the relationship between absolute discoveries and opportunity-normalized persistent events. A compressed alternate representation saturated under fast switching, whereas the larger primary phenotype map remained far from saturation through 5,000 generations. These are model-specific observations that motivate a larger, independently implemented and prospectively frozen study. They do not demonstrate open-ended evolution.

## Evidence-status summary

- **PROPOSED:** test the environment-by-interaction-graph effect on descendant-persistent first-seen phenotypes.
- **OBSERVED:** control gates passed; the fast-versus-static interaction estimate was −0.0078 per 1,000 eligible births with a 95% bootstrap interval spanning zero; representation and opportunity controls changed observed outcomes.
- **INTERPRETED:** the current runs are exploratory and conditional on one finite implementation.
- **HYPOTHESIZED:** environmental timing or local competition could affect which novel traits persist; the current data do not identify a mechanism.
- **NOT SUPPORTED:** OEE, unbounded novelty, a general network effect, a critical regime, or a verified literature gap.

## References

1. Taylor, T. (2019). Evolutionary Innovations and Where to Find Them: Routes to Open-Ended Evolution in Natural and Artificial Systems. *Artificial Life*, 25(2), 207–224. [https://doi.org/10.1162/artl_a_00290](https://doi.org/10.1162/artl_a_00290).
2. Dolson, E. L., Vostinar, A. E., Wiser, M. J., & Ofria, C. (2019). The MODES Toolbox: Measurements of Open-Ended Dynamics in Evolving Systems. *Artificial Life*, 25(1), 50–73. [https://doi.org/10.1162/artl_a_00280](https://doi.org/10.1162/artl_a_00280).
3. Adams, A., Zenil, H., Davies, P. C. W., & Walker, S. I. (2017). Formal Definitions of Unbounded Evolution and Innovation Reveal Universal Mechanisms for Open-Ended Evolution in Dynamical Systems. *Scientific Reports*, 7, 997. [https://doi.org/10.1038/s41598-017-00810-8](https://doi.org/10.1038/s41598-017-00810-8).
4. Channon, A. (2024). A Procedure for Testing for Tokyo Type 1 Open-Ended Evolution. *Artificial Life*, 30(3), 345–355. [https://doi.org/10.1162/artl_a_00430](https://doi.org/10.1162/artl_a_00430).
5. Cirne, D., & Campos, P. R. A. (2022). Rate of environmental variation impacts the predictability in evolution. *Physical Review E*, 106, 064408. [https://doi.org/10.1103/PhysRevE.106.064408](https://doi.org/10.1103/PhysRevE.106.064408).
6. Moreno, M. A., Rodriguez-Papa, S., & Dolson, E. (2025). Ecology, Spatial Structure, and Selection Pressure Induce Strong Signatures in Phylogenetic Structure. *Artificial Life*, 31(2), 129–152. [https://doi.org/10.1162/artl_a_00470](https://doi.org/10.1162/artl_a_00470).

## Items requiring author review

Confirm author names and contributions, agree on a software license and repository visibility, complete systematic literature searches and dual screening, obtain an independent implementation, decide whether to run a prospectively specified confirmatory replication, and revise the manuscript after external scientific review.
