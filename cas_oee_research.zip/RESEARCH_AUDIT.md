# Research and data audit

## Available source files

The active workspace was empty except for `outputs/` and `work/`. The earlier research files were in a neighboring Codex project and in the referenced ChatGPT conversation's attachments. The attachment set contained one Taylor OEE paper PDF and three pasted protocol drafts. The conversation preview also described a 200-run, 2,000-generation pilot, but no raw data, source code, or seed file supporting that particular run was present.

The neighboring package contained `model.py`, `RESEARCH_PACKAGE.md`, a clean pilot directory, a second accumulated CSV, two manifests, and a static results page.

## Audit of the earlier computational package

**OBSERVED:** The clean pilot manifest specifies 16 trajectories: eight environment × graph cells, two seeds per cell, 450 generations, \(N=100\), and per-bit mutation 0.01. Its CSV contains 7,200 rows (16 × 450), and its source hash matches the included v0.1 `model.py`. It is a traceable exploratory artifact.

**OBSERVED:** The v0.1 phenotype map is eight parity bits and therefore has exactly 256 possible phenotype codes. The research package reports complete 256/256 descriptor coverage in every changing-environment cell. The primary stored metric therefore saturates for those trajectories.

**OBSERVED:** v0.1 does not implement its specified lineage-persistence metric. `model.py` contains a placeholder loop and returns generation summaries without ancestry-based persistence outcomes. The clean pilot cannot answer the current primary question.

**OBSERVED:** A second CSV contains 62,370 rows. Its per-condition run lengths vary (including 250, 619, 1,000, and 1,250 observations). Its manifest states 1,000 generations and a source hash that does not match the adjacent `model.py`. This file is not used as evidence because its generating source and run boundaries cannot be reconciled from the available package.

**NOT SUPPORTED:** The conversation's earlier claim that the available pilot comprised 200 runs at 2,000 generations. That dataset was not found in the inspected workspace or adjacent project.

## Execution and analysis log

**OBSERVED:** The replacement measurement and implementation validation passed: synthetic lineage cases, a 1.6-million-bit mutation-rate calibration, connected degree-4 graph checks at \(N=50\) and \(N=100\), exact same-seed replay, and initial-census baseline exclusion.

**OBSERVED:** Two initial 32-run control batches completed but stopped before the primary factorial because of gate-reporting code defects. Their raw CSVs and manifests are preserved under `data/attempt_01_gate_schema_failure/` and `data/attempt_02_neutral_gate_comparison_bug/`. They are excluded from the final analysis and are not additional independent evidence. The corrected third execution passed the no-mutation, neutral-history, and graph-opportunity gates before running the planned study.

**OBSERVED:** The final frozen execution completed 240 planned trajectories across controls, mutation and demographic opportunity, the primary factorial, representation robustness, and long-horizon checks. Stage manifests preserve seeds, source hashes, and raw-file hashes.

**OBSERVED:** After inspecting the first analysis, an endpoint censoring issue was identified: the frozen \(NT\) denominator included the final 40 generations, whose innovations cannot complete the persistence follow-up. Raw data are unchanged. The original rate is retained; an eligible-exposure reanalysis using \(N(T-40)\) is explicitly marked post-run and exploratory in `ANALYSIS_AMENDMENT.md`.

## Scientific weaknesses repaired in this version

1. **Descriptor ceiling:** expanded the primary map from 256 to 6,561 phenotype states and added an explicit saturation horizon; the state space remains finite.
2. **Persistence ambiguity:** tagged the source carriers and followed descendants expressing the same phenotype, preventing unrelated reappearance from qualifying.
3. **Censoring:** events without a full 40-generation follow-up are retained as censored and excluded from the persistence rate denominator.
4. **Mutation and census opportunity:** added prespecified mutation-rate and population-size sensitivity stages; report rates per birth as well as absolute counts.
5. **Network opportunity:** both graphs are connected 4-regular graphs; each individual has exactly four contests and each run has exactly \(2N\) edges.
6. **Representation dependence:** added a prespecified parity-coded alternative representation and explicit phenotype-space coverage.
7. **Recurrence:** first-seen phenotypes are registered once; reappearance and exact phenotype-abundance recurrence are separate measures.
8. **Reproducibility:** split random streams, fixed stage seeds, source/data hashes, exact replay checks, and GitHub Actions validation.
9. **Pseudoreplication:** seed-blocked run summaries are the inferential unit; generations and organisms are not treated as independent replicates.

## Focused literature audit

The prior materials already correctly warn against treating novelty as synonymous with OEE, but their source list needs correction and expansion. The uploaded Taylor paper's published article distinguishes exploratory, expansive, and transformational novelty; this fixed representation directly studies exploratory novelty only. The MODES paper offers measures of change, novelty, complexity, and ecological potential, so a single custom endpoint should not be presented as a replacement for that toolbox. Adams et al. formalize innovation and unbounded evolution with counterfactual isolated-system comparisons, which this model does not implement. Channon's Tokyo Type 1 testing procedure provides additional checks for adaptive novelty and complexity growth that this project does not yet meet. Environmental switching-rate research and recent computational work on ecology/spatial structure also make the broad topic established rather than a verified novelty claim.

**Citation corrections:** the old source package gives Adams et al. DOI `10.1038/s41598-017-00861-x`; the verified DOI is `10.1038/s41598-017-00810-8`. Taylor's published article DOI is `10.1162/artl_a_00290`, distinct from the arXiv identifier `1806.01883`.

**Gap status:** **NOT SUPPORTED** as a broad claim that environment, networks, or evolutionary novelty are unstudied. Whether this exact outcome and factorial combination is novel remains **unverified**. A systematic database search, citation chaining, and two-person screening are still needed before a paper claims novelty of contribution.

**RIBE status:** The supplied material presents RIBE as a proposed research-audit checklist. It is not treated as an established scientific theory, does not enter the model or fitness function, and is not claimed to improve research quality in this study.

## Verified sources

- Adams, A. et al. (2017), [Formal Definitions of Unbounded Evolution and Innovation](https://www.nature.com/articles/s41598-017-00810-8), *Scientific Reports* 7, 997.
- Channon, A. (2024), [A Procedure for Testing for Tokyo Type 1 Open-Ended Evolution](https://direct.mit.edu/artl/article/30/3/345/120681/A-Procedure-for-Testing-for-Tokyo-Type-1-Open), *Artificial Life* 30(3), 345–355.
- Cirne, D. & Campos, P. R. A. (2022), [Rate of environmental variation impacts the predictability in evolution](https://journals.aps.org/pre/abstract/10.1103/PhysRevE.106.064408), *Physical Review E* 106, 064408.
- Dolson, E. et al. (2019), [The MODES Toolbox](https://direct.mit.edu/artl/article/25/1/50/2915/The-MODES-Toolbox-Measurements-of-Open-Ended), *Artificial Life* 25(1), 50–73.
- Moreno, M. A. et al. (2025), [Ecology, Spatial Structure, and Selection Pressure Induce Strong Signatures in Phylogenetic Structure](https://doi.org/10.1162/artl_a_00470), *Artificial Life* 31(2), 129–152.
- Taylor, T. (2019), [Evolutionary Innovations and Where to Find Them](https://doi.org/10.1162/artl_a_00290), *Artificial Life* 25(2), 207–224.
- [Open-Endedness for the Sake of Open-Endedness](https://doi.org/10.1162/artl_a_00289), *Artificial Life* 25(2), 198–212.

This is a focused audit, not a systematic review. The research gap and the paper's eventual contribution remain open questions.
