import unittest

from confirmatory_power_plan import normal_approximate_power, upper_sd_95_approx


class PlanningCalculationTests(unittest.TestCase):
    def test_upper_standard_deviation_bound_exceeds_pilot_estimate(self):
        self.assertGreater(upper_sd_95_approx(0.02848396068692241, 12), 0.02848396068692241)

    def test_planning_power_increases_with_blocks_and_effect(self):
        sigma = upper_sd_95_approx(0.02848396068692241, 12)
        baseline = normal_approximate_power(50, 0.02, sigma)
        self.assertGreater(normal_approximate_power(64, 0.02, sigma), baseline)
        self.assertGreater(normal_approximate_power(50, 0.03, sigma), baseline)
        self.assertGreaterEqual(normal_approximate_power(39, 0.02, sigma), 0.80)


if __name__ == "__main__":
    unittest.main()
