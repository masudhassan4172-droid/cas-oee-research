import random
import unittest

from analyze import event_rates_by_run
from model import (
    ALTERNATE_REPRESENTATION,
    PRIMARY_REPRESENTATION,
    decode,
    graph_summary,
    lineage_carries_phenotype,
    make_graph,
    mutate,
    persistence_decision,
    run_replicate,
)


class MeasurementTests(unittest.TestCase):
    def test_population_map_size_and_endpoints(self):
        self.assertEqual(decode(0, PRIMARY_REPRESENTATION)[2], 6561)
        self.assertEqual(decode((1 << 32) - 1, PRIMARY_REPRESENTATION)[1], 6560)
        self.assertEqual(decode(0, ALTERNATE_REPRESENTATION)[2], 256)
        self.assertEqual(decode(0x11111111, ALTERNATE_REPRESENTATION)[1], 255)

    def test_lineage_provenance_excludes_unrelated_recurrence(self):
        event_bit = 1 << 9
        self.assertTrue(lineage_carries_phenotype([9, 2], [event_bit, 0], 9, event_bit))
        self.assertFalse(lineage_carries_phenotype([9], [0], 9, event_bit))
        self.assertFalse(lineage_carries_phenotype([10], [event_bit], 9, event_bit))

    def test_persistence_threshold_and_censoring(self):
        self.assertTrue(persistence_decision(32, 40))
        self.assertFalse(persistence_decision(31, 40))
        self.assertIsNone(persistence_decision(39, 39))


class ModelTests(unittest.TestCase):
    def test_persistence_rate_uses_only_matured_birth_exposure(self):
        runs = [{"run_id": "r1", "population": "100", "generations": "100"}]
        events = [
            {"run_id": "r1", "right_censored": "0", "origin_generation": "60", "followup_steps": "40", "present_steps": "32"},
            {"run_id": "r1", "right_censored": "0", "origin_generation": "61", "followup_steps": "39", "present_steps": "39"},
            {"run_id": "r1", "right_censored": "1", "origin_generation": "60", "followup_steps": "39", "present_steps": "39"},
        ]
        self.assertAlmostEqual(event_rates_by_run(runs, events)["r1"], 1000.0 / 6000.0)

    def test_mutation_extremes(self):
        self.assertEqual(mutate(123, 0.0, random.Random(1)), (123, 0))
        self.assertEqual(mutate(0, 1.0, random.Random(1)), ((1 << 32) - 1, 32))

    def test_network_opportunity_is_matched(self):
        for kind in ("ring", "rewired_regular"):
            adjacency = make_graph(50, kind, random.Random(17))
            stats = graph_summary(adjacency)
            self.assertTrue(stats["connected"])
            self.assertEqual((stats["degree_min"], stats["degree_max"]), (4, 4))
            self.assertEqual(stats["edges"], 100)

    def test_seed_replay_and_baseline(self):
        config = {"seed": 9107, "population": 50, "generations": 35, "environment_period": 0, "network": "ring", "representation": PRIMARY_REPRESENTATION, "selection": "ecological", "mutation_rate": 0.002}
        first = run_replicate(config)
        second = run_replicate(config)
        self.assertEqual(first, second)
        self.assertEqual(first["series"][0]["new_phenotypes"], 0)
        self.assertEqual(first["series"][0]["new_genotypes"], 0)
        self.assertEqual(len(first["series"]), 36)


if __name__ == "__main__":
    unittest.main()
